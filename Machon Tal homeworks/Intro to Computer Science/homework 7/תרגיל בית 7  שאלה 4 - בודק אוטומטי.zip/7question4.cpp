//tamar harizy 
//209927128
//This program inputs 6 real numbers between 0 and 1 into an array called numbers. 
//The program should create a new array called indices of integers, 
//which contains the indices of the numbers in the array numbers in sorted ascending order
//then the program prints out the array indices
#include <iostream>
using namespace std;
//const integers
const int N = 6;
//main function
int main()
{
	int num = 10;
	float numbers[N];//array of real numbers between 0 to 1
	int indices[N] = { 10,10,10,10,10,10 };//an array that has the indices of the numbers in the array numbers in sorted ascending order
	float num1;//a float for the users inputs
	int print = 0;//an integer that goes through the array indices and prints out the variable
	cout << "enter 6 numbers between 0 and 1:" << endl;
	for (int i = 0; i < N; i++)//user inputs 6 numbers
	{
		cin >> num1;
		while ((num1 >= 1) || (num1 <= 0))//checks if the user input is valid
		{
			cout << "ERROR" << endl;
			i = 0;//user inputs new 6 numbers
			cin >> num1;
		}
		numbers[i] = num1;//inserts the number the user inputted into the array
	}
	int place1 = 0, place2 = 0;//one integer that saves the place of the minimum variable
	//another integer that runs through indices to see where we can save the variable that we saved in place1
	float min;
	for (int j = 0; j < N; j++)//runs through the array and saves each variable
	{
		place1 = j;//saves the place
		min = numbers[j];//saves the variable
		for (int n = 0; n < N; n++)//runs through the array and checks if there is a smaller number 
			// that can be the minimum
		{
			if (numbers[n] == 1)//checks if the variable is equal to 1
				continue;
			else if (min >= numbers[n])//checks if there is a number that is smaller to be the minimum
			{
				min = numbers[n];
				place1 = n;
			}
		}
		while (indices[place2] != num)//finds a place to insert the place that was saved
			place2++;
		indices[place2] = place1;//inserts the placement that was saved in the array
		place2 = 0;
		numbers[place1] = 1;
		
	}
	cout << "sorted indices:" << endl;
	while (print < N)//prints out the array indices
	{
		cout << indices[print]<<" ";
		print++;
	}
	cout << endl;
	return 0;
}

/*output:
enter 6 numbers between 0 and 1:
0.9 0.05 0.1 0.4 0.2 0.3
sorted indices:
1 2 4 5 3 0
*/