//tamar harizy 
//209927128
//This program reads in 6 positive integers into the array set1 and 6 positive integers into the array set2 
//and creates a third array called difference that contains the set difference of set1 and set2.
#include <iostream>
using namespace std;
//const integers
const int N = 6;
//main function
int main()
{
	int set1[N];
	int set2[N];
	int difference[N]={ 0,0,0,0,0,0 };//an array for the difference between the arrays set1 and set2
	cout << "enter first 6 numbers:" << endl;
	for (int i = 0; i < N; i++)//user inserts 6 numbers for the array set1
	{
		cin >> set1[i];
		while (set1[i] <= 0)//checks if the users input is valid
		{
			cout << "ERROR" << endl;
			cin >> set1[i];
		}
	}
	cout << "enter next 6 numbers:" << endl;//user inserts 6 numbers for the array set2
	for (int j = 0; j < N; j++)
	{
		cin >> set2[j];
		while (set2[j] <= 0)//checks if the users input is valid
		{
			cout << "ERROR" << endl;
			cin >> set2[j];
		}
	}
	int counter = 0,print=0;//and integer that will go through the array difference
	//and an integer that prints out the variables in the array difference
	bool diff = true;//boolean to help us check if the number in set1 is in set2
	for (int k = 0; k < N; k++)//runs through the array set1 and checks if any of the numbers are in set2
	{
		for (int a = 0; a < N; a++)//runs through the numbers in set2
		{
			if (set1[k] == set2[a])//checks if the number in set1 is also in set2
			{
				diff = false;
				break;
			}
		}
		if (diff == true)//checks if the number in set1 was not in set2
		{
			while (difference[counter] != 0)//inserts the remaining numbers in the array difference
			{
				counter++;
			}
			difference[counter] = set1[k];
			counter = 0;
		}
		diff = true;
	}
	cout << "set difference is:" << endl;
	int checkzero = 0;
	for (int l = 0; l < N; l++)
	{
		if (difference[l] != 0)
			checkzero = difference[l];
	}
	if (checkzero != 0)
	{
		while ((print < N) && (difference[print] != 0))//prints out the numbers in the array difference
		{
			cout << difference[print] << " ";
			print++;
		}
	}
	else
		cout << "empty" << endl;
	cout << endl;

	return 0;
}

/*output:
enter first 6 numbers:
10 9 7 5 3 1
enter next 6 numbers:
6 5 4 3 2 1
set difference is:
10 9 7
*/