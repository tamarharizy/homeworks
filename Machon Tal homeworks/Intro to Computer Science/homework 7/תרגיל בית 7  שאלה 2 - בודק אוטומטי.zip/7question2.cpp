//tamar harizy 
//209927128
//This program checks and prints out the number of times vector1 contains the elements in vector2
//that is, the number of times the elements in vector2 is repeated in vector1.
#include <iostream>
using namespace std;
//const integers
const int arr = 500;
const int N = 100;
//main function
int main()
{
	int vector1[arr] = { 0 };//two arrays
	int vector2[N] = { 0 };
	int num1, num2, counter1 = 0, counter2 = 0;//2 numbers for the users inputs
	//and 2 counters that run through the arrays
	cout << "enter size of first array:" << endl;
	cin >> num1;
	while ((num1 > 500) || (num1 < 0))//checks if the user input is valid
	{
		cout << "ERROR" << endl;
		cin >> num1;
	}
	cout << "enter first array values:" << endl;
	for (int i = 0; i < num1; i++)
		cin >> vector1[i];//user inputs numbers into array
	cout << "enter size of second array:" << endl;
	cin >> num2;
	while ((num2 > 100) || (num2< 0))//checks if the user input is valid
	{
		cout << "ERROR" << endl;
		cin >> num2;
	}
	cout << "enter second array values:" << endl;
	for (int j = 0; j < num2; j++)
		cin >> vector2[j];//user inputs numbers into array
	int place = 0;//integer that runs through the placement of the elements in vector2
	int k;
	for (int a = 0; a < num1; a++)//goes through all the numbers in vector1
	{
		if (vector1[a] == vector2[place])//checks if there is a possibility for vector2 to be in vector1
		{
			k = a;
			while ((vector1[a] == vector2[place])&&(vector1[a]!=0))//goes through both arrays to see if vector1 contains vector2
			{
				++counter1;
				++a;
				++place;
			}
			if (counter1 == num2)
				//counts the amount of times vector2 is in vector1
				counter2++;
			place = 0;
			counter1= 0;
			while(a>k)
			a--;
		}
	}
	cout << "result: " << counter2 << " times" << endl;//prints out result

	return 0;
}
/*output:
enter size of first array:
18
enter first array values:
6 5 4 3 2 1 6 5 4 3 2 1 6 5 4 3 2 1
enter size of second array:
4
enter second array values:
5 4 3 2
result: 3 times
*/