//tamar harizy 
//209927128
//This program inputs a list of values into an array of integers. The end of the input is marked with a 0 .
//The program should print the remaining elements as well as the number of remaining elements. 
#include <iostream>
using namespace std;
//const integers
const int N = 100;
//function
void function(int arr1[],int size,int place);
//main function
int main()
{
	int counter = 0,num1;
	int arr1[N];//an array where the users inputs are inserted
	cout << "enter up to 100  values, to stop enter 0" << endl;
	cin >> num1;
	while (counter < N)//lets the user insert maximum 100 numbers
	{
		if (num1 == 0)//checks if the user inserted 0,in order to know if to stop the loop
			break;
		arr1[counter]=num1;
		++counter;
		cin >> num1;
	}
	for (int i = 0; i < counter; i++)//saves each element in the array to check
		//each of them if they have any copies
	{
		for (int j = i + 1; j < counter; j++)//runs through the rest of the array 
		{
			while (arr1[i] == arr1[j])//checks if there is a number that theres double
			{
				function(arr1,counter,j);//invites the function function
				counter--;
			}
		}
	}
	int n = 0;
	cout << "the new vector is:" << endl;
	while (n != counter)//prints out the remaining numbers in the array
	{
		cout << arr1[n]<<" ";
		++n;
	}
	cout << endl;
	cout << "number of elements: " << counter << endl;//print out the amount of elements left in the array
	
	return 0;
}


void function(int arr1[], int size, int place)
//this function deletes the reapeating value that was sent to it as a variable
{
	int temp1, temp2;
	for (int i = size; i >= place; i--)//takes all the numbers in the array and moves them down
		//one place in order to delete the repeating value
	{
		if (i == size)//if were placed an the end of the array
			//it inputs in its place a 0 and saves the variable
		{
			temp1 = arr1[i];
			arr1[i] = 0;
		}
		else
		{//moves each value down by one place and saves the previous value
			temp2 = arr1[i];
			arr1[i] = temp1;
			temp1 = temp2;
		}
	}
}
/*output:
enter up to 100  values, to stop enter 0:
1 5 8 9 5 4 1 2 3 5 1 4 8 9 6 5 0
the vector is:
1 5 8 9 4 2 3 6
number of elements: 8
*/