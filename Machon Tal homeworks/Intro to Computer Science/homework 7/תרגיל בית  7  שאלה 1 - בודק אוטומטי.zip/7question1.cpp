//tamar harizy 
//209927128
//this program reads in 15 whole numbers and prints GOOD 
//if the list contains all 15 numbers between 1 and 15 and otherwise NOT GOOD.
#include <iostream>
using namespace std;
//const integer
const int N = 15;

//main function
int main()
{
	bool inarray = false, notgood = false;//a boolean that checks if the numbers are in the array
	//and another boolean to check if all the numbers were in the array
	int array[N];
	cout << "enter 15 numbers:" << endl;
	for (int i = 0; i < N; i++)//user inserts 15 numbers
		cin >> array[i];
	for (int j = 1; j <= N; j++)//goes through all the numbers between 1 to 15
	{
		inarray = false;
		for (int a = 0; a < N; a++)//goes through the array and checks if j(integer) is in the array
			if (array[a] == j)//checks if there is an element that has the number
				inarray = true;
		if (inarray == false)//checks it the number wasnt in the array
		{
			notgood = true;
			break;
		}
	}
	if (notgood == true)//checks if the array was good or not good
		cout << "NOT GOOD" << endl;
	else
		cout << "GOOD" << endl;

	return 0;
}
/*output:
enter 15 numbers:
15 8 9 7 1 3 4 2 10 14 6 5 13 12 11
GOOD
*/