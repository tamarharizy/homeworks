//tamar harizy
//209927128
//this program receives as input an array of integers and its size.
//it finds the reverse of the array and prints it out
#include <iostream>
using namespace std;
//functions
void swap(int* arr, int i, int j);
void reverse(int *arr, int num,int count);
//main function
int main() 
{
	int * arr;//pointer to point to the array
	int num;//an integer for the amount of elements in the array
	int count = 0;//an integer to help us reverse the array
	cout << "enter a number: "<<endl;
	cin >> num;
	arr = new int[num];//pointer arr now points to an array of integers size num
	cout << "enter array values: "<<endl;
	for (int i = 0; i < num; i++)//user inputs numbers into the array
		cin >> arr[i];

	cout << "before: \n";
	for (int i = 0; i < num; i++)//prints out array before the reverse
		cout << arr[i] << " ";
	cout << endl;
	reverse(arr, num,count);//invites the function reverse
	cout << "after: \n";
	for (int i = 0; i < num; i++)//prints out the final reversed array
		cout << arr[i] << " ";
	cout << endl;
	return 0;
}

void swap(int* arr, int i, int j)
//this function swaps the two elements it receives in the array
{
	int temp = arr[i];
	arr[i] = arr[j];
	arr[j] = temp;
}

void reverse(int *arr, int num, int count)
//This function reverses the elements of the array
{
	if (count >= num / 2)//checks if we already reversed the first half of the array
		return;
	swap(arr, count, num - count-1);//invites the function swap
	reverse(arr, num, ++count);//invites the function reverse
}
/*output:
enter a number:
6
enter array values:
1 2 3 4 5 6
before:
1 2 3 4 5 6
after:
6 5 4 3 2 1
*/