//tamar harizy
//209927128
//this program receives as input an array of integers and its size. 
//it sorts the array in non-descending order using selection sort
//and prints out the array before and after the sorting
#include <iostream>
using namespace std;
//functions
void swap(int* arr, int i, int j);
int smallest(int *arr, int num, int count,int small);
void sort(int *arr, int num, int count);
//main function
int main()
{
	int * arr;//pointer to point to the array
	int num,count=0;//an integer for the amount of elements in the array
	//and an integer to help us sort the array
	do {
		cout << "enter a number:" << endl;
		cin >> num;
		if (num <= 0)
			cout << "ERROR" << endl;
	} while (num <= 0);//loops as long as the users input isnt valid
	arr = new int[num];//pointer arr now points to an array of integers size num
	cout << "enter array values: "<<endl;
	for (int i = 0; i < num; i++)//user inputs numbers into the array
		cin >> arr[i];
	cout << "before: \n";
	for (int i = 0; i < num; i++)//prints out array before the sorting
		cout << arr[i] << " ";
	cout << endl;
	sort(arr, num,count);//invites the function sort
	cout << "after: \n";
	for (int i = 0; i < num; i++)//prints out the final sorted array
		cout << arr[i] << " ";
	cout << endl;

	return 0;
}

void swap(int* arr , int i, int j)
//this function swaps the two elements it receives in the array
{
	int temp = arr[i];
	arr[i] = arr[j];
	arr[j] = temp;
}

int smallest(int *arr, int num,int count,int small)
//this function
{
	if (count == num)//checks if we reached the end of the array
		return small;
	if (arr[count] <= arr[small])//checks if the element in place count is smaller then the element in place small
			small=count;
	smallest(arr, num, ++count,small);//invites the function smallest
}

void sort(int *arr, int num,int count)
//this function sorts the array in non-descending order using selection sort
{
	if (count == num)//checks if we reached the end of the array
		return;
	int small=count;
	small= smallest(arr, num, count,small);//invites the function smallest
	swap(arr,count, small);//invites the function swap

	sort(arr, num, ++count);//invites the function sort
}
/*output:
enter a number:
4
enter array values:
4 5 6 9
before:
4 5 6 9
after:
4 5 6 9
*/