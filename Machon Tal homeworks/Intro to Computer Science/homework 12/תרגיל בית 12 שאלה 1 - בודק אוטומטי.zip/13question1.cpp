//tamar harizy
//209927128
//this program receives a non-negative integer num as input. 
//it prints out num times the letter a followed by num times the letter b with no spaces. 
//If n is 0, the function prints nothing.
#include <iostream>
using namespace std;
//functions
void printABs(int num,int count);
//main function
int main() 
{
	int num,count=0;
	//an integer for the users input and an integer to count the amount we printed out
	cout << "enter a number:" << endl;
	cin >> num;//users input
	while (num < 0)//loops while the users input isnt valid
	{
		cout << "ERROR" << endl;
		cin >> num;
	}
	if(num!=0)//if the users input does not equal 0
	printABs(num,count);//invites the function printABs
	cout << endl;

	return 0;
}

void printABs(int num, int count)
//this function prints num times the letter a followed by num times the letter b with no spaces
{
	static char chr = 'a';//defines the character the user is going to print
	if (count == num)//checks if the character was printec out the amount of num times
	{
		count = 0;
		if (chr == 'b')//checks if already b was printed out
			return;
		else
			++chr;//increments the character
	}
	cout << chr;
	printABs(num, ++count);//invites the function printABs
}
/*output:
enter a number:
3
aaabbb

*/