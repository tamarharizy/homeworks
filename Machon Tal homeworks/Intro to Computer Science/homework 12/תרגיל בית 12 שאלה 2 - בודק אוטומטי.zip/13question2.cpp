//tamar harizy
//209927128
//this program recieves a positive integer representing the size of the array,
//and declares a dynamically allocated memory for the array of that size. 
//Afterwards, it inputs the elements for the array and prints the smallest element in the array.
#include <iostream>
using namespace std;
//functions
int smallest(int *array, int num, int count);
//main function
int main() 
{
	int * array;//a pointer to an integer
	int count = 0;//an integer that will help loop throughout the array
	int num;//an integer for the users input
	do {
		cout << "enter a number:" << endl;
		cin >> num;
		if (num <= 0)//checks if the users input isnt valid
			cout << "ERROR" << endl;
	} while (num <= 0);//loops as long as the users input isnt valid
	array = new int[num];//defines that array is pointing to an array if integers of size num
	cout << "enter array values: "<<endl;
	for (int i = 0; i < num; i++)//user inputs numbers into the array
		cin >> array[i];
	cout << "the smallest is: " << array[smallest(array, num,count)] << endl;//invites the function smallest

	return 0;
}

int smallest(int *array, int num,int count)
//this function finds the index of the smallest element in the array
{
	static int small=count;//small only at first will equal to count
	if(count==num)//checks if we have reached the end of the array
		return small;
	if (array[small] >= array[count])//checks if the number in place count is smaller then the 
		//number in place small
		small = count;
    smallest(array, num, ++count);//invites the function smallest
}
/*output:
enter a number:
6
enter array values:
2 4 5 1 5 6
the smallest is: 1
*/