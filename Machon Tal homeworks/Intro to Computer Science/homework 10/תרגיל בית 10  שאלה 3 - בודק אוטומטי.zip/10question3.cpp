//tamar harizy 
//209927128
//This program is given 2 strings, text and word, no larger than 80 characters
//and prints out the minimum gap size of the containment of word in text. 
//If word does not appear in text, the function returns -1
#include <iostream>
#include <fstream>
#include <cstring>
#include <string>
using namespace std;
//functions
int findsjump(char text[], char word[]);
//main function
int main()
{
	int jump;
	char text[80];//an array for the text
	char word[80];//an array for the word 
	cout << "enter text: ";
	cin.getline(text, 80);//user inserts text
	cout << endl;
	cout << "enter word: ";
	cin.getline(word, 80);//user inserts word
	cout << endl;
	jump = findsjump(text, word);//invites the function findsjump
	cout << "size of jump: " << jump << endl;

	return 0;
}


int findsjump(char text[], char word[])
//this function receives 2 strings and returns the minimum gap size of the containment of word in text. 
//If word does not appear in text, the function returns -1
{
	char *p1 = text, *p2 = word;//2 pointer to run through both strings
	int jump = -1, countjump = 0;//an integer to save the size of the jump
	//and an integer to count the size of the jump
	int j = 0,i,place1,place2;
	//2 integers to run through the strings
	//and 2 integers to save the placements of characters in the text
	for (i = 0; i < 80; i++)//loops through the text string
	{
		if (*(p1 + i) == NULL)//checks if it has reached the end of the sentence
			break;
		if (*(p2 + j) == *(p1 + i))//checks if character in string word is in the string text
		{
			if (j != 0)//checks if j isnt placed in the beginning of the string word
			{
				countjump = 0;
				for(place1 = i; place1-1 > place2;place1--)
					countjump++;
				if (jump == 0)
					jump = countjump;
				else if (jump != countjump)//checks if the size of the jump is the same
					continue;
			}
			else
				jump = 0;
			place2 = i;
			++j;
		}
	}
	if ((*(p1 + i) == NULL) && (*(p2 + j) != NULL))//checks if it has reached the end of the sentence
		//and didnt reach the end of the word
		return -1;
	return jump;//returns the gap size
}
/*output:
enter text: yesterday

enter word: sed

size of jump: 1
*/