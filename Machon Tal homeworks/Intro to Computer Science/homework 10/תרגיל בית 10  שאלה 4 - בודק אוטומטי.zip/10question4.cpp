//tamar harizy
//209927128
//This program stores words in lexicographical order by doing dynamic allocation
//The main program asks the user to insert a number between 0-5, and according to that
//it calls the appropriate function.
//the user can add a word or delete the word from the lexicon,can print all the words,search for a word
//and print out all the words that start with a certain character
#include <string.h>
#include <iostream>
#include <cstring>
#include <string>
using namespace std;
//functions
void newStr(char** &lexicon, int &lexisize, char word[]);
void delStr(char** &lexicon, int &lexisize, char word[]);
void printAll(char** &lexicon, int &lexisize);
int searchStr(char** &lexicon, int &lexisize, char word[]);
void printChar(char** &lexicon, int &lexisize, char chr);
//enum
enum choices { ADDSTR, DELSTR, SEARCH, PRINTCHR, PRINT, EXIT };

//main function
int main()
{
	int sizelexi = 0;//size of the array lexicon
	int choice = 0;//the users input
	char chr;//the character the user chooses to search
	char word[80];//an array for the words the user inputs
	int found;//helps check if the word exists in the lexicon
	char** lexicon = new char*[sizelexi];//an array of pointers that holds all the words in the dictionary

	do {
		cout << "enter 0-5:" << endl;
		cin >> choice;//user inputs a number from 0-5
		switch (choice)
		{
		case ADDSTR:
			cout << "enter the word:" << endl;
			cin >> word;//user inputs word to add
			newStr(lexicon, sizelexi, word);//invites the function newStr
			printAll(lexicon, sizelexi);//invites the function printAll
			break;
		case DELSTR:
			cout << "enter the word to delete:" << endl;
			cin >> word;//user inputs word to delete
			delStr(lexicon, sizelexi, word);//invites the function delStr
			printAll(lexicon, sizelexi);//invites the function printAll
			break;
		case SEARCH:
			cout << "enter the word to search for:" << endl;
			cin >> word;//user inputs word to search
			found = searchStr(lexicon, sizelexi, word);//invites the function searchStr
			if (found == -1)//checks if the word wasn't found
				cout << "not found" << endl;
			else
				cout << "found" << endl;
			break;
		case PRINTCHR:
			cout << "enter the char:" << endl;
			cin >> chr;//userv inputs letter to search
			printChar(lexicon, sizelexi, chr);//invites the function printChr
			break;
		case PRINT:
			printAll(lexicon, sizelexi);//invites the function printAll
			break;
		case EXIT:
			break;
		}

	} while (choice != 5);//loops as long as the users input doesn't equal 0

	return 0;
}


void newStr(char** &lexicon, int &lexisize, char word[])//this function adds a word to the dictionary.
{
	int  j = 0;//an integer to help us run through the pointers in lexicon
	int saveline = lexisize;//an integers that saves the placement of the string
	if (searchStr(lexicon, lexisize, word) != -1)//checks if what the function searchStr
		//returned is -1
		return;
	for (int i = 0; i < lexisize; i++)//runs through the pointers in lexicon
	{
		if (strcmp(lexicon[i], word) > 0)//checks if the string lexicon[i]
			//is pointing to comes after word in the diictionary
		{
			saveline = i;//saves the place that it wants to insert the new string 
			//the user inputted
			break;
		}
	}
	++lexisize;//decrements the amount of pointers there are going to be in the lexicon
	char** temp = new char*[lexisize];//a temporary array of pointers that will hold all the words in the dictionary
	//including the string the user inputted
	for (int k = 0; k < lexisize; k++)//runs through the pointers in lexicon
	{
		temp[k] = new char[80];//temp[i] will point to an array thats size 80
		if (k == saveline)//checks if the k equals the line that we saved
			strcpy(temp[k], word);//copies string in word into lexicon
		else
		{
			strcpy(temp[k], lexicon[j]);//copies strings in lexicon into temp
			delete[]lexicon[j];//deletes the string lexicon[i] is pointing to
			++j;
		}
	}
	delete lexicon;//deletes what lexicon is pointing to
	lexicon = temp;
}

void delStr(char** &lexicon, int &lexisize, char word[])
//this function deletes a string from the dictionary
{
	int j = 0,k=0;//an integer to help us run through the pointers in lexicon
	//and an integer to help us run through the pointers in temp
	if (searchStr(lexicon, lexisize, word) == -1)//checks if what the function searchStr
		//returned is -1
		return;
	--lexisize;//decrements the amount of pointers there are going to be in the lexicon
	char** temp = new char*[lexisize];
	//a temporary array of pointers that will hold all the words in the dictionary
	//not including the string the user inputted
	while( k < lexisize)
	{
		temp[k] = new char[80];//temp[i] will point to an array thats size 80
		if (strcmp(lexicon[j], word) != 0)//checks if the string lexicon[i]
			//is pointing to comes after word in the diictionary
		{
			strcpy(temp[k], lexicon[j]);//copies strings in lexicon into temp
			++k;
		}
		delete[]lexicon[j];//deletes the string lexicon[i] is pointing to
		++j;
	}
	delete lexicon;//deletes what lexicon is pointing to
	lexicon = temp;
}

void printAll(char** &lexicon, int &lexisize)
//this function prints the dictionary
{
	for (int i = 0; i < lexisize; i++)//runs through the pointers in lexicon
		cout << lexicon[i] << " ";
	cout << endl;
}

int searchStr(char** &lexicon, int &lexisize, char word[])
//this function search for a given string in the dictionary.
{
	int line = -1;//if the string doesnt exist,the integer line will be -1
	for (int i = 0; i < lexisize; i++)//runs through the pointers in lexicon
	{
		if (strcmp(lexicon[i], word) == 0)//checks if the string pointer lexicon[i]
			//is pointing to equals the string the user inputted to search
		{
			line = i;
			break;
		}
	}
	return line;//returns the line where the string that the user searched is placed
}

void printChar(char** &lexicon, int &lexisize, char chr)
//this function prints all words in the dictionary which start with a given character.
{
	int j = 0;
	for (int i = 0; i < lexisize; i++)//runs through the pointers in lexicon
	{
		if (lexicon[i][j] == chr)//checks if the first character of the string is the same as the users input
			cout << lexicon[i] << " ";
	}
	cout << endl;
}
/*output:
enter 0-5:
0
enter the word:
abc
abc
enter 0-5:
0
enter the word:
bcd
abc bcd
enter 0-5:
1
enter the word to delete:
abc
bcd
enter 0-5:
2
enter the word to search for:
bcd
found
enter 0-5:
3
enter the char:
b
bcd
enter 0-5:
4
bcd
enter 0-5:
5
*/