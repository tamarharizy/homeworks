//tamar harizy 
//209927128
//This program receives as input a string sentence not greater than 80 characters 
//and finds its reverse string sentence
#include <iostream>
#include <fstream>
#include <cstring>
#include <string>
using namespace std;
//functions
void reverse(char sentence[], int size, char *p);
//main function
int main()
{
	char sentence[80];//an array for the sentence the user inserts
	char *p = sentence;//a pointer to run through the sentence
	cout << "enter a string: " << endl;
	cin.getline(sentence, 80);//user inserts sentence
	reverse(sentence, 80, p);//invites the function reverse
	cout << "after reverse: ";
	int i = 0;
	while (*(p + i) != NULL)//prints out the final reversed sentence
	{
		cout << *(p + i);
		++i;
	}
	cout << endl;

	return 0;
}

void reverse(char sentence[], int size, char *p)
//this function receive a string sentence
//not greater than 80 characters and returns its reverse string sentence
{
	int sizeword = 0,start,n;//an integer that saves the sixe of each word in the sentence
	//and 2 integers to help us put back the final reversed word back into the array
	char temp2;//a character to help us reverse the characters
	char wordreverse[80];//an array to help us find the reversed words in the sentence
	for (int i = 0; i < size; i++)//loops through the string(the sentence)
	{
		if ((*p + i) == NULL)//checks if it has reached the end of the sentence
			break;
		else if ((*(p + i) != ' ') && (*(p + i) != NULL))//checks if element is part of a word in the sentence
		{
			start = i;
			while ((*(p + i) != ' ') && (*(p + i) != NULL))//loops till the end of the word
			{
				wordreverse[sizeword] = *(p + i);//saves the word in the array wordreverse
				++i;
				++sizeword;
			}
			for (int j = 0; j < sizeword / 2; j++)//reverses the characters in the word
			{
				temp2 = wordreverse[j];
				wordreverse[j] = wordreverse[sizeword - 1 - j];
				wordreverse[sizeword -1- j] = temp2;
			}
			n = 0;
			while (n < sizeword)//inserts the reversed word back into the array sentence
			{
				sentence[start] = wordreverse[n];
				++start;
				++n;
			}
			sizeword = 0;
		}
	}
}
/*output:
enter a string:
This is a silly88 sentence
after reverse: sihT si a 88yllis ecnetnes
*/