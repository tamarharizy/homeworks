//tamar harizy 
//209927128
//This program reads from a file a string up to 80 characters long.
//The program then calls the function crypto and prints the encrypted string 
#include <iostream>
#include <fstream>
#include <cstring>
#include <string>
using namespace std;
//functions
void crypto(char string[],int size,char *p);

//main function
int main()
{
	ifstream file;//a reading stream to the file 
	char string[80];//an array of characters that its maximum size is 80
	char chr,*p=string;//a character to run through the file
	//and a pointer to the array of character
	int size = 0;//an integer that finds the size of the string
	file.open("string.txt");
	if (!file)//checks if we can open file
	{
		cout << "sorry ,your file cannot be opened for writing" << endl;
		file.close();//closes the file
		return 0;
	}
	while ((file >> chr) && (size <= 80))//continues while chr can run through the file
		//and the size of the string is no bigger than 80
	{
		*(p+size) = chr;//inputs character into the array
		++size;
	}
	crypto(string,size,p);//invites the function crypto
	for (int i = 0; i < size; i++)//prints out the final encrypted string
		cout << *(p + i);
	cout << endl;

	file.close();//closes the file

	return 0;
}


void crypto(char string[],int size,char *p)//this function receives a string
//and finds the encrypted string 
{
	char chr;//saves each character throughout the loop
	int temp;//helps us find the encrypted character for each character
	
	for (int i = 0; i < size; i++)//runs through the array string
	{
		chr = *(p + i);
		if ((chr >= 'a') && (chr <= 'z'))//checks if the character is in the alphabet
		{
			temp = chr - 'a';
			chr = 'z' - temp;
			*(p + i) = chr;
		}
	}
}
/*output:
yzA?yz
*/