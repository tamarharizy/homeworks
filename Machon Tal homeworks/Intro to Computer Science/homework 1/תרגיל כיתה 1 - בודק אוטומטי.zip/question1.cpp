#include <iostream>
using namespace std;
int main()
{
	cout << "Have a nice day!" << endl;
		//system("pause");
	return 0;
}