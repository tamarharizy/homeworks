//tamar harizy
//209927128
//this program creates an array of items(structs) for products in a store.
//it saves for each item their code,name,amount,price, and minimum amount.
//this programs allows the user to add items,find prices, sell,order,and print out the products in the store.
#include <string.h>
#include <iostream>
#include <cstring>
#include <string>
using namespace std;
//struct
struct Item
{
	int pcode;
	char pname[20];
	int amount;
	int minamount;
	float price;
};
//enum
enum cases { EXIT, ADD, FIND, SOLD, ORDER, PRINT };
//functions
void addItem(Item *store, int maxItems,int &numItems);
void findPrice(Item *store, int &numItems);
void sold(Item *store, int &numItems);
void order(Item *store, int &numItems);
void print(Item *store, int &numItems);

int main()
{
	Item* store;//a pointer to a type struct called item
	int maxItems;//the maximum number of products you can have in the store
	int numItems = 0;//the amount of items currently in the store
	int choice;//the users choice input
	cout << "enter max number of items: " << endl;
	cin >> maxItems;//user inserts maximum amount of items
	store = new Item[maxItems];//creates an array of structs in size of the maximum amount of items

	do {
		cout << "enter 0-5:\n";
		cin >> choice;
		switch (choice) {
		case EXIT:	break;
		case ADD:	addItem(store, maxItems, numItems);//invites the function addItem
			break;
		case FIND: 	findPrice(store, numItems);//invites the function findPrice
			break;
		case SOLD:	sold(store, numItems);//invites the function sold
			break;
		case ORDER:	order(store, numItems);//invites the function order
			break;
		case PRINT: print(store, numItems);//invites the function print
			break;
		default: 	cout << "ERROR" << endl;
		}
	} while (choice != 0);//loops as the as the users input is not 0

	return 0;
}


void addItem(Item *store, int maxItems, int &numItems)
//this function  adds a new product to the array of items
{
	int place = numItems;//finds the place where we will need to add or change product information
	int code, amount, minamount;
	float price;
	char name[20];
	//user inputs the information of the item
	cout << "enter code:" << endl;
	cin >> code;
	cout << "enter name:" << endl;
	cin >> name;
	cout << "enter amount:" << endl;
	cin >> amount;
	cout << "enter minimum amount:" << endl;
	cin >> minamount;
	cout << "enter price:" << endl;
	cin >> price;
	for (int i = 0; i < numItems; i++)//loops through the products inside the array
	{
		if (code == store[i].pcode)//checks if the product exists in the array(store)
		{
			if (strcmp(name,store[i].pname)==0)//checks if both the users input and the product have the same name
				store[i].amount += amount;//adds the amount of the item to the stock
			else
				cout << "ERROR" << endl;//users input is not valid
			return;
		}
	}
	if (numItems < maxItems)//checks if there is room for more products in the array(store)
	{
		//inputs the products information inside the array
		store[place].pcode = code;
		strcpy(store[place].pname, name);
		store[place].amount = amount;
		store[place].minamount = minamount;
		store[place].price = price;
		++numItems;//increments the amount of items in the array(store)
	}
	else
		cout << "ERROR" << endl;//if there no more room in the array(store)
}

void findPrice(Item *store, int &numItems)
//this function finds the price of a product
{
	int code;
	cout << "enter code:" << endl;
	cin >> code;//user inputs the code of the product
	for (int i = 0; i < numItems; i++)//loops through the products inside the array
	{
		if (code == store[i].pcode)//checks if the product exists in the array(store)
		{
			cout <<"price: "<< store[i].price << endl;//prints out the products price
			return;
		}
	}
	cout << "ERROR" << endl;//if the product does not exist in the array(store)
}

void sold(Item *store, int &numItems)
//this function records a sale that happens in the store
{
	int code, amount;
	cout << "enter code:" << endl;
	cin >> code;//user inputs the code of the product
	cout << "enter amount:" << endl;
	cin >> amount;//user inputs amount they need from the product
	for (int i = 0; i < numItems; i++)//loops through the products inside the array
	{
		if (code == store[i].pcode)//checks if the product exists in the array(store)
		{
			store[i].amount -= amount;//takes of the amount was sold from the product
			return;
		}
	}
	cout << "ERROR" << endl;//if the product does not exist in the array(store)
}

void order(Item *store, int &numItems)
//this function updates the stock in the store
{
	int addstock;//an integer that helps us check the amount of stock we need to add
	for (int i = 0; i < numItems; i++)//loops through the products inside the array
	{
		if (store[i].amount < store[i].minamount)//checks if the amount in stock is smaller then the minimum amount
		{
			addstock = store[i].minamount - store[i].amount + 5;//finds the amount they need to add
			cout << "item name: " << store[i].pname << endl;
			cout << "code:" << store[i].pcode << endl;
			cout << "amount to order:" << addstock << endl;
			store[i].amount += addstock;//adds the amount to stock
		}
	}
}

void print(Item *store, int &numItems)
//this function prints out the current stock
{
	for (int i = 0; i < numItems; i++)//loops through the products inside the array
	{
		cout << "name: "<<store[i].pname<<endl;
		cout << "code: " << store[i].pcode << endl;
		cout << "amount: " << store[i].amount << endl;
		cout << "minimum amount: " << store[i].minamount << endl;
		cout << "price: " << store[i].price << endl;
		cout << endl;
	}
}
/*output:
enter max number of items:
2
enter 05:
1
enter code:  		
100
enter name:
paper
enter amount:
200
enter minimum amount:
50
enter price:
28.90
enter 05:
1
enter code:
101
enter name:
pens
enter amount:
75
enter minimum amount:
80
enter price:
6.90
enter 05:
1
enter code:
100
enter name:
paper
enter amount:
50
enter minimum amount:
50
enter price:
28.90
enter 05:
1
enter code:
102
enter name:
pencils
enter amount:
300
enter minimum amount:
250
enter price:
1.75
ERROR 	 	

enter 05:
5 				// code 5 - print
name: paper
code:  100
amount:250
minimum amount:50
price: 28.9

name: pens
code: 101
amount: 75
minimum amount: 80
price: 6.9

enter 05:
2 				
enter code:
103
ERROR
enter 05:
2
enter code:
101
price: 6.9
enter 05:
4 				
item name: pens
code:  101
amount to order: 10
enter 05:
5
name: paper
code:  100
amount:250
minimum amount:50
price: 28.9

name: pens
code: 101
amount: 85
minimum amount: 80
price: 6.9
enter 05:
3 				
enter code:
100
enter amount:
200

enter 05:
5
name: paper
code:  100
amount:50
minimum amount:50
price: 28.9

name: pens
code: 101
amount: 85
minimum amount: 80
price: 6.9

enter code:
0
*/