//tamar harizy 
//209927128
//this program reads in 2 positive whole numbers and prints the area of the rectangle.
//it also reads in a positive whole number and prints the area of the corresponding circle 
#include <iostream>
using namespace std;
//functions in the program
int area(int length, int width);
double area(int radius);
//main function
int main()
{
	int num1, num2, rectangle, radius;//4 integers
	//for the users input and for the results of the function 
	double circle;//double to get the result of the function
	cout << "enter length and width of the rectangle:" << endl;
	cin >> num1 >> num2;//user inputs length and width of rectangle
	while ((num1 <= 0) || (num2 <= 0))//checks if what the user inserted is valid
	{
		cout << "ERROR" << endl;
		cin >> num1 >> num2;
	}
	rectangle = area(num1, num2);//calls the function int area
	cout << rectangle << endl;//prints
	cout << "enter radius of the circle:" << endl;
	cin >> radius;
	while (radius <= 0)//checks if what the user inserted is valid
	{
		cout << "ERROR" << endl;
		cin >> radius;
	}
	circle = area(radius);//calls the function double area
	cout << circle << endl;//prints
	return 0;
}


int area(int length, int width)//this function recieves the length and the width of the rectangle
//and finds the area of the rectangle
{
	int result;
	result = length * width;
	return result;
}

double area(int radius)//this function recieves a radius to a circle
//and finds the area of the circle
{
	double PI = 3.14159, circle;
	circle = radius *radius* PI;
	return circle;

}