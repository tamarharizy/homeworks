//tamar harizy 
//209927128
//this program reads in a whole number and checks If the number is negative or zero, \
//if yes ,the program randomly chooses a number from 10-100. The program finds the smallest prime number greater than or equal to the whole number supplied. 
// and that number will be the table size.
#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;
//functions
bool  isPrime(int number);
int findPrime(int number);
//main function
int main()
{
	srand((unsigned)time(NULL));//makes sure the function will pick a different
	//random number each time its run
	int num1, result;
	//an integer for the users input and an integer for the final prime number
	cout << "enter number of values:" << endl;
	cin >> num1;//
	if (num1 <= 0)//checks if what the user inserted is negative
		num1 = rand() % (91) + 10;
	result = findPrime(num1);
	cout << "table size:" << result << endl;
	return 0;
}
 
bool  isPrime(int number)//this function checks if the number that was received
//is a prime number
{
	bool prime = true;
	for (int i = 2; i < number / 2; i++)
	{
		if (number%i == 0)
			prime = false;
	}
	if (prime == true)//if the number is a prime number
		return true;
	else
		return false;
}

int findPrime(int number)//this function checks if the number that was inserted is prime
//if not, checks which number that is greater than it and is a prime
{
	while (isPrime(number) == false)
		number = number + 1;
	return number;
}