//tamar harizy 
//209927128
//this program reads in a number and prints out a list of all perfect numbers less than the number inputted 
//and also a list of all perfect numbers less than 500.
#include <iostream>
using namespace std;
//functions
bool perfect(int number);
void perfectnumbers(int number=500);
//main function
int main()
{
	int num1;//integer for the user to insert a number
	cout << "enter a number:" << endl;
	cin >> num1;//user inserts number
	while (num1 <= 0)//checks if what the user inserted is valid
	{
		cout << "ERROR" << endl;
		cin >> num1;
	}
	perfectnumbers(num1);//invites the function perfectnumber
	cout << endl;
	perfectnumbers();//invites the function perfectnumber
	cout << endl;

	return 0;

}


bool perfect(int number)//this function recieves a number and checks if the
//number is a perfect number
{
	int sum = 0;
	for (int i = 1; i <= number / 2; i++)
	{
		if (number%i == 0)//checks if its a factor
			sum += i;
	}
	if (number == sum)//if the number that was recieved is a perfect number
		return true;
	else
		return false;
}

void perfectnumbers(int number)//this function goes through all the number between
//0 to the number the user inserted and checks which of the numbers are perfect
{
	for (int i = 1; i < number; i++)
		if (perfect(i))//invites the function perfect
			cout << i << " ";
}