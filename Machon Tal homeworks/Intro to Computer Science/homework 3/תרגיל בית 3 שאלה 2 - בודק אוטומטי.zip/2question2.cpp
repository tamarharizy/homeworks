//tamar harizy 
//209927128
//this program checks if a given number falls within a specified range (that is also given)
#include <iostream>
using namespace std;
int main()
{
	int first, last, number;//3 numbers
	cout << "enter 3 numbers:" << endl;
	cin >> first >> last >> number;//user inserts 3 numbers
	if ((first <= number) && (number <= last))//checks if the number is within the range
		cout << "between" << endl;
	else if (number > last)//checks if the number is bigger then the range
		cout << "bigger" << endl;
	else//if the number is smaller then the range
		cout << "smaller" << endl;
	return 0;
}
/*output:
enter 3 numbers
3 9 11
bigger
*/