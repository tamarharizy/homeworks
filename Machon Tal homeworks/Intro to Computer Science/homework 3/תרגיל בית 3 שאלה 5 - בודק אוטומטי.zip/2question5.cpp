//tamar harizy 
//209927128
//this program reads in 3 numbers and prints the input numbers in non-decreasing order
#include <iostream>
using namespace std;
int main()
{
	int num1, num2, num3, smallest, middle, biggest;//3 numbers and three integers for the smallest,middle and biggest number
	cout << "enter 3 numbers:" << endl;
	cin >> num1 >> num2 >> num3;//user inserts 3 numbers
	//checks which of the numbers is the biggest number and saves it into the integer biggest
	if ((num3 >= num2) && (num3 >= num1))
		biggest = num3;
	else if ((num2 >= num1) && (num2 >= num3))
		biggest = num2;
	else
		biggest = num1;
	//checks which of the numbers is the middle number and saves it into the integer middle
	if (((num1 <= num2)&&(num2 <= num3)) || ((num3 <= num2) &&(num2<= num1)))
		middle = num2;
	else if (((num2 <= num1)&&(num1 <= num3)) || ((num3 <= num1)&&(num1 <= num2)))
		middle = num1;
	else
		middle = num3;
	//checks which of the numbers is the smallest number and saves it into the integer smallest
	if ((num1 <= num3) && (num1 <= num2))
		smallest = num1;
	else if ((num2 <= num3) && (num2 <= num1))
		smallest = num2;
	else
		smallest = num3;
	cout << smallest << " " << middle << " " << biggest << endl;//prints out the final result
	return 0;
}
/*output:
enter 3 numbers:
9 6 1
1 6 9
*/