//tamar harizy 
//209927128
//this program reads a number from 1-12 (each number represents a month)
//and prints out the number of days that are in that month
#include <iostream>
using namespace std;
enum MONTHS{JAN=1,FEB,MARCH,APRIL,MAY,JUNE,JULY,AUG,SEP,OCT,NOV,DEC};//defined as global type
int main()
{
	int month;
	cout << "enter a number:" << endl;
	cin >> month;//user inserts a number
	if ((month <= 0) || (month > 12))
	{
		cout << "ERROR" << endl;
		return 0;
	}
	switch (month)//checks which month was inserted
	{
	case JAN://for month 1,3,5,7,8,10,12
	case MARCH:
	case MAY:
	case JULY:
	case AUG:
	case OCT:
	case DEC:
		cout << "31 days in the month" << endl;
		break;
	case APRIL://for month 4,6,9,10
	case JUNE:
	case SEP:
	case NOV:
		cout << "30 days in the month" << endl;
		break;
	case FEB://for month 2
		cout << "28 days in the month" << endl;
		break;
	}
	return 0;
}
