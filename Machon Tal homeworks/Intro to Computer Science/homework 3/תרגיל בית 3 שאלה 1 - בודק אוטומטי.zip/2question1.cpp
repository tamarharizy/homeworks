//tamar harizy 
//209927128
//this program receives a positive integer less than 100 (double-digit number),
//and checks if the digits are odd or even
#include <iostream>
using namespace std;
int main()
{
	int num, sum, singular, tens;
	cout << "enter a number:" << endl;
	cin >> num;//user inserts a number
	if ((num >= 100) || (num < 10))//checks if the input is in range
	{
		cout << "ERROR" << endl;
		return 0;
	}
	else
	{
		singular = num % 10;
		tens = num / 10;
		if ((singular % 2 != 0) && (tens % 2 != 0))//checks if the digits are odd
		{
			cout << "odd digits only" << endl;
			sum = singular + tens;
			cout << sum << endl;
		}
		else if ((singular % 2 == 0) && (tens % 2 == 0))//checks if the two digits are even
		{
			cout << "even digits only" << endl;
			sum = singular * tens;
			cout << sum << endl;
		}
		else//if the two digits are both odd and even
			cout << "mixed number" << endl;
		return 0;
	}
}
/*output:
enter a number
28
even digits only
16
*/