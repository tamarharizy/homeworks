//tamar harizy 
//209927128
//this program asks the user to enter 3 numbers and checks whether a triangle can be formed from these 3 sides
//if yes, it checks what type of calculator
#include <iostream>
using namespace std;
int main()
{
	int num1, num2, num3;//3 numbers
	cout << " enter 3 numbers:" << endl;
	cin >> num1 >> num2 >> num3;//user inserts 3 numbers
	if ((num1 <= 0) || (num2 <= 0) ||( num3 <= 0))//checks if there is an error in the users input
	{
		cout << "ERROR" << endl;
		return 0;
	}
	if (((num1 + num2) > num3) && ((num2 + num3) > num1) && ((num1 + num3) > num2))
			//checks if the numbers that the user inserted can create a llegal triangle
	{
			if ((num1 == num2) && (num2 == num3))//checks if the triangle is an equilateral triangle
				cout << "equilateral triangle" << endl;
			else if (((num1 == num2) && (num3 <= num1 + num2)) ||
				((num2 == num3) && (num1 <= num2 + num3)) ||
				((num1 == num3) && (num2 <= num1 + num3)))//checks if the triangle is an isosceles triangle
				cout << "isosceles triangle" << endl;
			else
				cout << "scalene triangle" << endl;
	}
	else
		cout << "cannot form a triangle" << endl;
	return 0;
}
/*output:
 enter 3 numbers:
1 7 5
cannot form a triangle
*/
