//tamar harizy 
//209927128
//this program reads in two numbers and an arithmetic operator as a character
//prints the whole exercise and the result using a switch statement.
#include <iostream>
using namespace std;
int main()
{
	int num1, num2;//two number
	double sum;
	char opr;//the operator
	cout << "enter 2 numbers:" << endl;
	cin >> num1 >> num2;//user inserts 2 numbers
	cout << "enter an operator" << endl;
	cin >> opr;
	if ((opr != '+') && (opr != '*') && (opr != '-') && (opr != '/'))
	{
		cout << "ERROR" << endl;
		return 0;
	}
	switch (opr)//checks which operator the user inputted
	{
	case '+':
		sum = num1 + num2;
		break;
	case '-':
		sum = num1 - num2;
		break;
	case '*':
		sum = num1 * num2;
		break;
	case '/':
		if (num2 == 0)
		{
			cout << "ERROR" << endl;
			return 0;
		}
		else
		{
			sum = (float)num1 / num2;
			break;
		}
	}
	cout << num1 << opr << num2 << '=' << sum << endl;
	return 0;
}
/*output:
enter 2 numbers:
10 2
enter an operator
/
10/2=5
*/