//tamar harizy 
//209927128
//this program asks the user to enter 2 positive numbers. 
//If the inputs are not legal then the program prints ERROR until it receives legal input for both number (checks them separately)
//then the program reads in a list of integers until their sum is greater than the first number or the amount of numbers read is equal to the second number
//and prints out the subtotal
#include <iostream>
using namespace std;
int main()
{
	int num1, num2 , sum=0, counter = 0, number;
	cout << "enter 2 positive numbers:" << endl;
	cin >> num1;
	while (num1 <= 0)//checks if what the user inserted is valid
	{
		cout << "ERROR" << endl;
		cin >> num1;
	}
	cin >> num2;
	while(num2<=0)//checks if what the user inserted is valid
	{
		cout << "ERROR" << endl;
		cin >> num2;
	}
	cout << "enter a list of numbers:" << endl;
	while ((sum <= num1) && (counter < num2))
		//stays in the loop as long sum is greater than the first number and the amount of numbers read is smaller or equal to the second number
	{
		cin >> number;
		sum += number;
		counter++;
	}
	cout << sum << endl;
	return 0;
}
/*output:
enter 2 positive numbers:
25
5
enter a list of number:
9
8
7
6
30
*/