//tamar harizy 
//209927128
//this program reads in a non-negative whole number n. If it receives an illegal number, it prints ERROR until it receives a legal input. 
//The output of the program is the first n+1 numbers in the Fibonacci series.
#include <iostream>
using namespace std;
int main()
{
	int n, num1 = 0, num2 = 0, number;//integer for amount of numbers being printed out 
	//and 3 more integer going through the series and creating each number
	cout << "enter a number:" << endl;
	cin >> n;
	while (n < 0)//checks if what the user inserted is valid
	{
		cout << "ERROR" << endl;
		cin >> n;
	}
	for (int i = 0; i < n + 1; i++)//print out n+1 numbers of the fibonacci series
	{
		if (i == 0)//first case
		{
			num1 = 0;
			cout << num1 << " ";
		}
		else if (i == 1)//second case
		{
			num2 = 1;
			cout << num2 << " ";
		}
		else//the rest of the cases
		{
			number = num1 + num2;
			cout << number << " ";
			num1 = num2;
			num2 = number;
		}
	}
	cout << endl;
	return 0;
}
/*output:
enter a number:
9
0 1 1 2 3 5 8 13 21 34
*/