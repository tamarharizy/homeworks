//tamar harizy 
//209927128
//this program computes the sum of the first n elements of the series
// +... + ((-1) n - 1 / 2n - 1)X2n - 1
//The program reads in 2 integers corresponding to X and n and prints ERROR until it receives legal inputs.The output is the exact sum computed.
#include <iostream>
using namespace std;
int main()
{
	int X, N, numer, denom, base;//2 integers inserted into the program and 3 integers for numerator,denominator and base of exponential term
	float num, sum = 0,number = 0;//floats for adding up the elements in the series
	cout << "enter 2 numbers:" << endl;
	cin >> X >> N;
	while (N <= 0)//checks if what the user inserted is valid
	{
		cout << "ERROR" << endl;
		cin >> N;
	}
	for (int i = 0; i < N; i++)//runs the amount of elements the user inserted
	{
		//the numerator
		if (i%2==0)//checks if the placement of the element is an odd or even placement
			numer = 1;
		else
			numer=-1;
		if (i == 0)//first case only numerator,denominator
		{
			num = 1;
			denom = 1;
		}
		else
			denom += 2;
		    num = (float)(numer )/ denom;
		if (i == 0)//first case only
			base = X;
		else
			base = base *(X*X);
		number = (float)base*num;
		sum += number;//adding up the subtotal
	}
	cout << sum << endl;
	return 0;
}
/*output:
enter 2 numbers:
3
2
-6
*/