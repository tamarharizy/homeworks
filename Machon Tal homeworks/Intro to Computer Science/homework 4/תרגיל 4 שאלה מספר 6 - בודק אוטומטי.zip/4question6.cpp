//tamar harizy 
//209927128
//this program reads a number thats a single positive integer. If it receives an illegal number, it prints ERROR until it receives a legal input. 
//The program then checks if each digit is one smaller than the previous digit on its left, and prints YES  or NO accordingly.
#include <iostream>
using namespace std;
int main()
{
	int number, checker, minimum = 0;//3 integers 
	//one for the user input and two others checking the number that was inserted is in nondecending order
	bool prime=true;
	cout << "enter a number:" << endl;
	cin >> number;//user inputs a number
	while (number <= 0)//checks if what the user inserted is valid
	{
		cout << "ERROR" << endl;
		cin >> number;
	}
	while (number != 0)//checks each digit in the number that was inserted
		//until it reaches zero
	{
		checker = number % 10;
		if (minimum == 0)
			minimum = checker;
		else
		{
			if (minimum + 1 != checker)//checks if digit is going in nondecending order
				prime = false;
			else
				minimum = checker;
		}
		number = number / 10;
	}
	if (prime == false)//checks if digit is going in nondecending order
		cout << "NO" << endl;
	else
		cout << "YES" << endl;
	return 0;
}
