//tamar harizy 
//209927128
//this program reads in a positive single digit and print out a pyramid such that the first line contains the numbers n to 1 in descending order
//the second line n-1 to 1 and so on until it prints a line containing only the number 1
#include <iostream>
using namespace std;
int main()
{
	int number, blank = 0;//an integer for the user input and an integer for the amount of blanks in each row
	cout << "enter a one digit number:" << endl;
	cin >> number;//user enters the amount of rows in the pyramid
	while ((number > 9) || (number <= 0))//checks if what the user inserted is valid
	{
		cout << "ERROR" << endl;
		cin >> number;
	}
	for (int i = number; i > 0; i--)//loops the amount of the the user inputted
	{
		for (int j = 0; j < blank; j++)//prints the amount of blanks there need to be in each row
			cout << " ";
		blank += 3;
		for (int r = i; r > 0; r--)//prints out numbers in each row
		{
			if (r == 1)
				cout << r;
			else
				cout << r << ", ";
		}
		cout << endl;//next row
	}
	return 0;
}