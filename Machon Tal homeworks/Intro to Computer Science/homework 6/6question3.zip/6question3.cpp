//tamar harizy 
//209927128
//this program receives input from 4 files, each containing student grades.
//The program outputs to the console the message highest average found in file and the index of the file which contains the highest average.
#include <iostream>
#include <fstream>
using namespace std;
//functions
float average(ifstream& stream);
//main function
int main()
{
	float avg1,avg2,avg3,avg4;//4 integers for each average of each file
	ifstream stream1;
	ifstream stream2;
	ifstream stream3;
	ifstream stream4;
	stream1.open("grade1.txt");
	if (!stream1)//checks if we can open file
	{
		cout << "sorry ,your file cannot be opened for writing" << endl;
		stream1.close();
		return 0;
	}
	stream2.open("grade2.txt");
	if (!stream2)//checks if we can open file
	{
		cout << "sorry ,your file cannot be opened for writing" << endl;
		stream2.close();
		return 0;
	}
	stream3.open("grade3.txt");
	if (!stream3)//checks if we can open file
	{
		cout << "sorry ,your file cannot be opened for writing" << endl;
		stream3.close();
		return 0;
	}
	stream4.open("grade4.txt");
	if (!stream4)//checks if we can open file
	{
		cout << "sorry ,your file cannot be opened for writing" << endl;
		stream4.close();
		return 0;
	}
	avg1=average(stream1);//calling the function for each file to find out the average for each file
	avg2=average(stream2);
	avg3=average(stream3);
	avg4=average(stream4);
	cout << "highest average found in file ";
	if ((avg1 >= avg2) && (avg1 >= avg3) && (avg1 >= avg4))//checks if the file grade1 has the highest average
		cout << "1";
	else if ((avg2 >= avg1) && (avg2 >= avg3) && (avg2 >= avg4))//checks if the file grade2 has the highest average
		cout << "2";
	else if ((avg3 >= avg2) && (avg3 >= avg1) && (avg3 >= avg4))//checks if the file grade3 has the highest average
		cout << "3";
	else
		cout << "4";
		cout << endl;

	return 0;
}


float average(ifstream &stream)//this function receives a file and finds the average of all the grades in the file
{
	int num,counter=0;//integers for the amount of grades and the subtotal of all of them
	float sum = 0;
	while (stream >> num)//goes through all the numbers in file
	{
		sum += num;
		counter++;
	}
	sum = sum / (float)counter;//finds average
	return sum;
}