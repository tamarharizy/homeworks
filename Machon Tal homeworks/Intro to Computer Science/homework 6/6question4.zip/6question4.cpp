//tamar harizy 
//209927128
//this program receives a file named information.txt ,then the program creates a new file named frequencyDigits.txt 
//and record in this file the frequency of all digits in the input file. 
#include <iostream>
#include <fstream>
using namespace std;

//main function
int main()
{
	ifstream info;//a reading stream to the file with the information
	ofstream freqDigits;//a writing stream to a new file called frequencyDigits
	info.open("information.txt");
	if (!info)//checks if we can open file
	{
		cout << "sorry ,your file cannot be opened for writing" << endl;
		info.close();
		return 0;
	}
	freqDigits.open("frequencyDigits.txt");
	if (!freqDigits)//checks if we can open file
	{
		cout << "sorry ,your file cannot be opened for writing" << endl;
		freqDigits.close();
		return 0;
	}
	freqDigits << "digit "<<'\t' << "frequency" << endl;
	char ch,temp='0';//a character that runs through the file
	//and a character that checks goes through the number 0 to 9
	int counter = 0;//integer that finds the frequency of each number
	for (int i = 0; i < 10; i++)//a loop that runs through all the digits
	{
		counter = 0;
		while (info >> ch)//runs through the whole file until the end of the file
		{
			if (ch == temp)//checks if the character that we ahve saved in ch is equal to the number were looking for
				counter++;
		}
		freqDigits << i << '\t' << counter << endl;//prints in other folder the digit and the frequency of it
		temp += 1;
		info.close();
		info.open("information.txt");
	}
	info.close();//closing all files
	freqDigits.close();
	return 0;
}