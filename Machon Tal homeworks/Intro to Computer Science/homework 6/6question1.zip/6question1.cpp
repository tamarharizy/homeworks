//tamar harizy 
//209927128
//this program opens 2 files,one with id numbers and one with grades, and creates a third file.
//we read the ids and grades from the two files.the third file combines the students ids and grades.
//afterwards it checks if there was anything in the first 2 files that werent printed into the third file
//and prints out which file and what wasnt inputted
#include <iostream>
#include <fstream>
using namespace std;
//main function
int main()
{
	int id_number, num;//2 integers to go into 2 different files
	ifstream file1;//a reading stream to the file with ids
	ifstream file2;//a reading stream to the file with grades
	ofstream newfile;//a writing stream to a new file
	file1.open("id.txt");
	if (!file1)//checks if we can open file
	{
		cout << "sorry ,your file cannot be opened for writing" << endl;
		file1.close();
		return 0;
	}
	file2.open("grades.txt");
	if (!file2)//checks if we can open file
	{
		cout << "sorry ,your file cannot be opened for writing" << endl;
		file2.close();
		return 0;
	}
	newfile.open("roster.txt");
	if (!newfile)//checks if we can open file
	{
		cout << "sorry ,your file cannot be opened for writing" << endl;
		newfile.close();
		return 0;
	}
	while ((file1 >> id_number) && (file2 >> num))//inserts and combines both grades and ids into the third file
		newfile << id_number << " " << num << endl;
	if ((!file1.eof()) && (file2.eof()))//checks if we finished reading grades before id
	{
		cout << "finished reading grades before id" << endl;
		while (file1 >> id_number)
		{
			if(id_number>0)
				cout << id_number << endl;
		}

	}
	else if ((file1.eof()) && (!file2.eof()))//checks if we finished reading id before grades
	{
		cout << "finished reading id before grades" << endl;
		while (file2 >> num)
		{
			if (num > 0)
				cout << num << endl;
		}
	}
	file1.close();//closing all files
	file2.close();
	newfile.close();
	
	return 0;
}
