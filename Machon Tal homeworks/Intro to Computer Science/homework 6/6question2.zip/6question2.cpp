//tamar harizy 
//209927128
//this program opens and reads a file called data.txt and creates a new file called encoding.txt 
//which contains the data of data.txt in encrypted form. 
#include <iostream>
#include <fstream>
using namespace std;
//functions
char switchfunc(char &letter);
//main function
int main()
{
	char letter,newletter;//2 character,one for the original character ,and one for the new encoded character
	ifstream text;//a reading stream to the file with the data
	ofstream newtext;//a writing stream to a new file called encoding
	text.open("data.txt");
	if (!text)//checks if we can open file
	{
		cout << "sorry ,your file cannot be opened for writing" << endl;
		text.close();
		return 0;
	}
	newtext.open("encoding.txt");
	if (!newtext)//checks if we can open file
	{
		cout << "sorry ,your file cannot be opened for writing" << endl;
		newtext.close();
		return 0;
	}
	while (text.get(letter))//while the stream text doesn't reach the end of the file data
	{
		newletter=switchfunc(letter);//calls the function switchfunc
		newtext << newletter;//inserts the new letter into the encrypted file
	}
	text.close();//closing all files
	newtext.close();

	return 0;
}

char switchfunc(char &letter)//this function gets a character and returns its encrypted character
{
	switch (letter)//checks what the character is
	{
	case 'a':
		letter = 'z';
		break;
	case 'b':
		letter = 'y';
		break;
	case 'c':
		letter = 'x';
		break;
	case 'd':
		letter = 'w';
		break;
	case 'e':
		letter = 'v';
		break;
	case 'f':
		letter = 'u';
		break;
	case 'g':
		letter = 't';
		break;
	case 'h':
		letter = 's';
		break;
	case 'i':
		letter = 'r';
		break;
	case 'j':
		letter = 'q';
		break;
	case 'k':
		letter = 'p';
		break;
	case 'l':
		letter = 'o';
		break;
	case 'm':
		letter = 'n';
		break;
	case 'n':
		letter = 'm';
		break;
	case 'o':
		letter = 'l';
		break;
	case 'p':
		letter = 'k';
		break;
	case 'q':
		letter = 'j';
		break;
	case 'r':
		letter = 'i';
		break;
	case 's':
		letter = 'h';
		break;
	case 't':
		letter = 'g';
		break;
	case 'u':
		letter = 'f';
		break;
	case 'v':
		letter = 'e';
		break;
	case 'w':
		letter = 'd';
		break;
	case 'x':
		letter = 'c';
		break;
	case 'y':
		letter = 'b';
		break;
	case 'z':
		letter = 'a';
		break;
	case 'A':
		letter = 'Z';
		break;
	case 'B':
		letter = 'Y';
		break;
	case 'C':
		letter = 'X';
		break;
	case 'D':
		letter = 'W';
		break;
	case 'E':
		letter = 'V';
		break;
	case 'F':
		letter = 'U';
		break;
	case 'G':
		letter = 'T';
		break;
	case 'H':
		letter = 'S';
		break;
	case 'I':
		letter = 'R';
		break;
	case 'J':
		letter = 'Q';
		break;
	case 'K':
		letter = 'P';
		break;
	case 'L':
		letter = 'O';
		break;
	case 'M':
		letter = 'N';
		break;
	case 'N':
		letter = 'M';
		break;
	case 'O':
		letter = 'L';
		break;
	case 'P':
		letter = 'K';
		break;
	case 'Q':
		letter = 'J';
		break;
	case 'R':
		letter = 'I';
		break;
	case 'S':
		letter = 'H';
		break;
	case 'T':
		letter = 'G';
		break;
	case 'U':
		letter = 'F';
		break;
	case 'V':
		letter = 'E';
		break;
	case 'W':
		letter = 'D';
		break;
	case 'X':
		letter = 'C';
		break;
	case 'Y':
		letter = 'B';
		break;
	case 'Z':
		letter = 'A';
		break;
	case '0':
	case '1':
	case '2':
	case '3':
	case '4':
	case '5':
	case '6':
	case '7':
	case '8':
		letter = letter + 1;
		break;
	case '9':
		letter = '0';
		break;
	}
	return letter;
}