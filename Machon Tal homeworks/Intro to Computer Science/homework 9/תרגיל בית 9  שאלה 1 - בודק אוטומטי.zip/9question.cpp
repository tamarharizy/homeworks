//tamar harizy
//209927128
//this program creates a matrix for 50 bus lines, for there stations and for there time duration
//the user in this program by pressesing number from 0-7,can add and delete lines,search a bus line,
//find the bus line with the shortest travel,
//find the average of the travel, and of the stops of all the buses.
#include <iostream>
using namespace std;
//enum
enum choices { EXIT, ADD, DELETE, PRINT, SEARCH, AVG_TRAVEL, AVG_STOPS, SHORTEST_TRAVEL };
//functions
void addLine(int buses[][3], int & numBuses, int line, int stops, int durationOfRide);
void deleteLine(int buses[][3], int & numBuses, int line);
int search(int buses[][3], int numBuses, int line);
float averageTravel(int buses[][3], int numBuses);
int averageStops(int buses[][3], int numBuses);
int shortest(int buses[][3], int numBuses);
void print(int buses[][3], int numBuses);
void sort(int buses[][3],int numBuses);
//main function
int  main() 
{
	int buses[50][3];//the matrix for the buses
	int numBuses = 0;//an integer that saves the amount of lines inside the matrix
	int line, stops, durationOfRide, choice;
	//integers for the users input in order to add,delete, and search lines
	do {
		cout << "enter 0-7" << endl;
		cin >> choice;//user inputs a number from 0-7
		switch (choice) {
		case ADD: // add a line to the array of buses
			cout << "enter the line to add" << endl;
			cin >> line;//line number
			while (line <= 0)//checks if the input was valid
			{
				cout << "ERROR" << endl;
				cin >> line;
			}
			cout << "enter the number of stops" << endl;
			cin >> stops;//amount of stops on the line
			while (stops <= 0)//checks if the input was valid
			{
				cout << "ERROR" << endl;
				cin >> stops;
			}
			cout << "enter the duration of the ride" << endl;
			cin >> durationOfRide;//duration of the ride
			while (durationOfRide <= 0)//checks if the input was valid
			{
				cout << "ERROR" << endl;
				cin >> durationOfRide;//user reinputs a new integer
			}
			addLine(buses, numBuses, line, stops, durationOfRide);//invites the function addLine
			print(buses, numBuses);//invites the function print
			break;
		case DELETE:	// delete a line from the array of buses					
			cout << "enter the line to delete" << endl;
			cin >> line;//line number
			deleteLine(buses, numBuses, line);//invites the function deleteLine
			print(buses, numBuses);//invites the function print
			break;
		case PRINT: // print all lines
			print(buses, numBuses);//invites the function print
			break;
		case SEARCH: // search for a particular line
			cout << "enter the line to search for" << endl;
			cin >> line;//line number
			cout << search(buses, numBuses, line) << endl;//invites the function search
			break;
		case AVG_TRAVEL: // calculate average travel time of all buses
			cout << averageTravel(buses, numBuses) << endl;//invites the function averageTravel
			break;
		case AVG_STOPS:  // calcuate average stops of all buses
			cout << averageStops(buses, numBuses) << endl;//invites the function averageStops
			break;
		case SHORTEST_TRAVEL:// calculate the bus with the shortest travel time
			cout << shortest(buses, numBuses) << endl;//invites the function shortest
			break;
		case EXIT: break;   // exit the program

		default:  cout << "ERROR" << endl;
		}// switch
	} while (choice != 0);//loops as long as the users input is not 0

	return 0;
}

void print(int buses[][3], int numBuses) 
//this function prints out the buses that are saved in the database
{

	for (int i = 0; i < numBuses; i++) { // for each bus that is present in the database
		for (int j = 0; j < 3; j++) { // prints the 3 pieces of data of the bus
			cout << *(*(buses + i) + j) << " ";
		}
		cout << endl;
	}
}

void addLine(int buses[][3], int & numBuses, int line, int stops, int durationOfRide)
//this function adds a new bus line to the system. 
{
	int i = 0;
	if (numBuses == 50)//checks if the matrix is full
	{
		cout << "ERROR" << endl;
		return;
	}
	else
	{
		i = 0;
		if (search(buses, numBuses, line) == -1)//invites the function search
		{
			while (i<numBuses)//loops to the end of the list of the bus lines
				i++;
		}
		for (int k = 0; k < 3; k++)//inputs the users information into the matrix
		{
			if (k == 0)//if k is placed on the line column
				*(*(buses + i) + k) = line;
			else if (k == 1)//if k is placed on the stop column
				*(*(buses + i) + k) = stops;
			else
				*(*(buses + i) + k) = durationOfRide;
		}
	}
	numBuses++;//increases the size of the number of buses
	sort(buses, numBuses);//invites the function sort
}

void deleteLine(int buses[][3], int & numBuses, int line)
//this function removes an existing line from the system. 
{
	for (int i = 0; i < numBuses; i++)//loops through the list of bus lines
	{
		if (buses[i][0] == line)//checks if he found the bus line the user inputted
			//by checking if its equal
		{
			for (int j = i + 1; j < numBuses; j++)//deletes the line by overlapping
				//with a different bus line
				for (int n = 0; n < 3; n++)
					*(*(buses + i) + n) = *(*(buses + j) + n);
			numBuses--;//decreases the size of the number of buses
			break;
		}
	}
	sort(buses, numBuses);//invites the function sort
}

int search(int buses[][3], int numBuses, int line)
//this function searches for a given line number in the system. 
{
	for (int i = 0; i < numBuses; i++)//loops through the bus lines
	{
		if (*(*(buses + i) + 0) == line)//checks if the line number is in the system
			return i;
	}
	return -1;//if the number was not in the system
}

float averageTravel(int buses[][3], int numBuses)
//this function calculates the average duration of the bus lines that exist in the system. 
{
	int average=0;
	for (int i = 0; i < numBuses; i++)//loops through the time duration of all the bus lines in the system
		average += *(*(buses + i) + 2);
	return average / (float)numBuses;//returns the average time
}

int averageStops(int buses[][3], int numBuses)
//this function calculates the average number of stops of the bus lines that exist in the system. 
{
	int average = 0;
	for (int i = 0; i < numBuses; i++)//loops through the stops of all the bus lines in the system
		average += *(*(buses + i) + 1);
	return average /numBuses;//returns the average of stops
}

int shortest(int buses[][3], int numBuses)
//this function finds the line with the shortest travel time. 
{
	int line=-1;
	int shortest;
	for (int i = 0; i < numBuses; i++)//loops through the bus line
	{
		if (i == 0)//checks if i is placed on the first line
		{
			shortest = *(*(buses + i) + 2);
			line = *(*(buses + i) + 0);
		}
		else
			if (*(*(buses + i) + 2) < shortest)//checks if there is another bus line
				//with a shorter travel time
			{
				shortest = *(*(buses + i) + 2);
				line = *(*(buses + i) + 0);
			}
	}
	return line;//the line with the shortest travel time 
}

void sort(int buses[][3],int numBuses)
//this function sort the matrix by the number of the bus lines in ascending order
{
	int temp;//an integer to help us swap  bus lines throughout the matrix
	for(int i=0;i<numBuses;i++)//loops through the bus lines
		for(int j=i+1;j<numBuses;j++)//loops though the bus lines
			if (*(*(buses + i) + 0) > *(*(buses + j) + 0))//checks if there needs to be a swap in order 
				//for the list to be in ascending order
			{
				for (int n = 0; n < 3; n++)//swaps the lines
				{
					temp = *(*(buses + i) + n);
					*(*(buses + i) + n) = *(*(buses + j) + n);
					*(*(buses + j) + n) = temp;
				}
			}
}
/*output:
enter 0-7
1
enter the line to add
1
enter the number of stops
2
enter the duration of the ride
3
1 2 3
enter 0-7
1
enter the line to add
4
enter the number of stops
5
enter the duration of the ride
6
1 2 3
4 5 6
enter 0-7
2
enter the line to delete
4
1 2 3
enter 0-7
1
enter the line to add
7
enter the number of stops
8
enter the duration of the ride
9
1 2 3
7 8 9
enter 0-7
3
1 2 3
7 8 9
enter 0-7
4
enter the line to search for
5
-1
enter 0-7
5
6
enter 0-7
6
5
enter 0-7
7
1
enter 0-7
0
*/