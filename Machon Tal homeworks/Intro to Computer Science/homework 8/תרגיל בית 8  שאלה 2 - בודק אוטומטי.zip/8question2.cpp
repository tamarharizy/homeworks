//tamar harizy 
//209927128
//This program reads in the elements of 3 lists. Each list contains at most 10 positive integers 
//(shorter lists are terminated with a 0) and are sorted in strictly descending order (no repeats).
//The program prints out the merge of the 3 lists.
#include <iostream>
using namespace std;
//functions
void inputarray(int arr[]);
int merge(int arr1[], int arr2[], int arr3[], int mergearr[]);
//const integers
const int N = 10;
const int n = 30;
//main function
int main()
{
	int arr1[N];//first vector
	int arr2[N];//second vector
	int arr3[N];//third vector
	int mergearr[n];//merge of all 3 vectors
	int size;//saves the size of the merged vector
	cout << "enter values for the first vector:" << endl;
	inputarray(arr1);//invites the function inputarray
	cout << "enter values for the second vector:" << endl;
	inputarray(arr2);//invites the function inputarray
	cout << "enter values for the third vector:" << endl;
	inputarray(arr3);//invites the function inputarray
	size=merge(arr1, arr2, arr3, mergearr);//invites the function merge
	cout << "merged vector is:" << endl;
	int j = 0;
	while ((j < size)&&(mergearr[j]!=0))//prints out the merged vector
	{
		cout << mergearr[j] << " ";
		j++;
	}
	cout << endl;

	
	return 0;
}

void inputarray(int arr[])//this function checks if the input by the user was valid
//inserts the users inputs into the vector
{
	bool descending = true;//boolean that checks if the users input is valid
	while (descending == true)//checks if the user input is valid
	{
		int i = 0;
		while (i < N)//user inputs numbers into the array
		{
			cin >> arr[i];
			if (arr[i] == 0)
				break;
			i++;
		}
		int j = 0;
		while (j<i)//checks if the numbers are in descending order
		{
			if (j != (i - 1))
				if (arr[j] <= arr[j + 1])
					descending = false;
			j++;
		}
		if (descending == true)//if the input is valid
			break;//leave the loop
		else//if input isn't valid
		{
			cout << "ERROR" << endl;
			descending = true;
		}
	}
}


int merge(int arr1[], int arr2[], int arr3[], int mergearr[])
//this function receives 3 vectors and turns them into one merged vector
{
	int i = 0, j = 0, k = 0, p = 0;
	//integers that run through all the vectors and the merged vector to input the numbers
	while (((i < N)||(arr1[i]!=0) )&& ((arr2[j] != 0)||(j < N))&&((arr3[k] != 0)||(k < N)) && (p < n))
		//runs through all the vectors
	{
		if ((arr1[i] >= arr2[j]) && (arr1[i] >= arr3[k]))//checks if the first vector is the biggest number
		{
			mergearr[p] = arr1[i];
			i++;
		}
		else if ((arr2[j] >= arr1[i]) && (arr2[j] >= arr3[k]))//checks if the second vector is the biggest number
		{
			mergearr[p] = arr2[j];
			j++;
		}
		else//if the third vector has the biggest number
		{
			mergearr[p] = arr3[k];
			k++;
		}
		p++;
	}
	//checks which of the vectors didnt reach the end 
	if (((i < N) || (arr1[i] != 0)) && ((arr2[j] != 0) || (j < N)))
		//if the first and second vector didnt reach the end
	{
		while (((i < N) || (arr1[i] != 0)) && ((arr2[j] != 0) || (j < N)) && (p < n))
			//runs through the first ,second and merged vector
		{
			if (arr1[i] >= arr2[j])//checks if the first vector is the biggest number
			{
				mergearr[p] = arr1[i];
				i++;
			}
			else//if the second vector has a bigger number
			{
				mergearr[p] = arr2[j];
				j++;
			}
			p++;
		}
	}
	else if (((i < N) || (arr1[i] != 0)) && ((arr3[k] != 0) || (k < N)))
	{//if the first and third vector didnt reach the end
		while (((i < N) || (arr1[i] != 0)) && ((arr3[k] != 0) || (k < N)) && (p < n))
			//runs through the first,third and merged vector
		{
			if (arr1[i] >= arr3[k])//checks if the first vector is the biggest number
			{
				mergearr[p] = arr1[i];
				i++;
			}
			else// if the third vector is the biggest number
			{
				mergearr[p] = arr3[k];
				k++;
			}
			p++;
		}
	}

	else if (((arr2[j] != 0) || (j < N)) && ((arr3[k] != 0) || (k < N)))
	{//if the second and third vector didnt reach the end
		while (((arr2[j] != 0) || (j < N)) && ((arr3[k] != 0) || (k < N)) && (p < n))
		{
			if (arr2[j] >= arr3[k])//checks if the second vector is the biggest number
			{
				mergearr[p] = arr2[j];
				j++;
			}
			else//if the third vector is the biggest number
			{
				mergearr[p] = arr3[k];
				k++;
			}
			p++;
		}
	}

	if (i < N)
		//if the first vector didnt reach the end
	{
		while ((i < N) && (p < n))//runs through the first vector and the merged vector
		{
			mergearr[p] = arr1[i];
			i++;
			p++;
		}
	}
	else if (j < N)
	{
		//if the second vector didnt reach the end
		while ((j < N) && (p < n))//runs through the second vector and the merged vector
		{
			mergearr[p] = arr1[j];
			j++;
			p++;
		}
	}
	else if (k < N)
	{
		//if the third vector didnt reach the end
		while ((k < N) && (p < n))//runs through the third vector and the merged vector
		{
			mergearr[p] = arr1[i];
			i++;
			p++;
		}
	}
	return p;//returns the size of the merged vector
}
/*output:
enter values for the first vector:
6 4 2 0
enter values for the second vector:
21 19 17 14 13 12 9 6 3 2
enter values for the third vector:
3 2 1 0
merged vector is:
21 19 17 14 13 12 9 6 6 4 3 3 2 2 2 1
*/