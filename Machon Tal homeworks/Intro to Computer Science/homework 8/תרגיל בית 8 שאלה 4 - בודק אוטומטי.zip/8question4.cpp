//tamar harizy 
//209927128
//This program inputs 10 words each containing 5 letters,  and stores them in a 10 x 5 matrix .
//Thos program uses bubble sort to sort the words in lexigraphical  (dictionary) order.
#include <iostream>
using namespace std;
//const integers
const int R = 10;
const int C = 5;
//functions
void sort(char mat[R][C]);
//main function
int main()
{
	char mat[R][C];//the matrix for the characters of the 10 words that contain 5 letters
	cout << " enter 10 words:" << endl;
	for (int i = 0; i < R; i++)//user inputs the 10 words into the matrix
		for (int j = 0; j < C; j++)
			cin >> mat[i][j];
	sort(mat);//invites the function sort
	cout << "after sorting:" << endl;
	for (int i = 0; i < R; i++)//prints out the final sorted array
		//that is sorted in lexigraphical  (dictionary) order.
	{
		for (int j = 0; j < C; j++)
		{
				cout << mat[i][j];
				if ((i == 4) && (j == 4))//checks if the loops get to the middle of the array
					cout << endl;
		}
		cout << " ";
	}
	cout << endl;


	return 0;
}

void sort(char mat[R][C])//this function takes the matrix that was inserted by the user
//and sorts it to be in lexigraphical  (dictionary) order.
{
	int k;
	int temp;//integer that will help us swap rows and sort the matrix
	for (int i = 0; i < R; i++)//goes through each row and saves each one
		for (int j = i + 1; j < R; j++)//runs through the rows(words)
		{
			k = i;
			if (mat[k][0] == mat[j][0])//checks if both of the words have of the first letter
				for (int l = 1; l < C; l++)//runs through the columns(letters)
				{
					if (mat[k][l] < mat[j][l])//checks if the letter i is before the letter in j 
					{
						k = j;
						break;
					}
					else if (mat[k][l] > mat[j][l])//checks if the letter j is before the letter in i
					{
						for (int p = 0; p< C; p++)//swaps the rows(words)int the matrix
						{
							temp = mat[i][p];//saves the letter in i
							mat[k][p] = mat[j][p];
							mat[j][p] = temp;
						}
						break;
					}
				}
			else if (mat[k][0] > mat[j][0])//checks if the letter i is before the letter in j
			{
				for (int p = 0; p < C; p++)//swaps the rows(words)int the matrix
				{
					temp = mat[k][p];//saves the letter in i
					mat[k][p] = mat[j][p];
					mat[j][p] = temp;
				}
			}
			else
				k = j;
		}
}

/*output:
 enter 10 words:
house apple teach array teach books point float apply begin
after sorting:
apple apply array begin books
 float house point teach teach
*/
