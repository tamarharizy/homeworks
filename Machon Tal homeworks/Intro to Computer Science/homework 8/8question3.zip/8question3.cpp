//tamar harizy 
//209927128
//This program inputs 100 positive integers from the file numbers.txt into a 10*10 matrix,and prints out the matrix.
//the program then uses insertion sort to sort the lower left triangle and the upper right triangle of the matrix in non-descending order.
//and then prints out the final matrix
#include <iostream>
#include <fstream>
using namespace std;
//functions
void sort(int arr[]);
//const integers
const int N = 10;
//main function
int main()
{
	ifstream num;//a reading stream to the file with the information- the numbers for the matrix
	int mat[N][N];//the matrix for the info in the file
	int arr[45];//an array that will help us do insertion sort on the matrix
	int num1,i=0,j=0,n=0;//an integer to help us run through the file,2 integers to run through the matrix
	//and another integer to run through the array
	num.open("numbers.txt");//opening the file
	if (!num)//checks if we can open file
	{
		cout << "sorry ,your file cannot be opened for reading" << endl;
		num.close();
		return 0;
	}
	while (num >> num1)//runs through the whole file until the end of the file
		//and inserts all the numbers in the file into a matrix
	{
		mat[i][j] = num1;
		++j;
		if (j == 10)//checks if it reaches the end of a row in a matrix
		{
			j = 0;
			i++;
		}
	}
	for (i = 0; i < N; i++)//prints out the current situation of the matrix
	{//runs through rows
		for ( j = 0; j < N; j++)//runs through columns
			cout << mat[i][j] << " ";
		cout << endl;
	}
	for ( i = 0; i < N; i++)//inserts the numbers in the upper right triangle in the matrix into the array
	{//runs through rows
		for (j = 0; j < N; j++)//runs through columns
			if (j > i)
			{
				arr[n] = mat[i][j];
				n++;
			}
	}
	sort(arr);//invites the function sort
	n = 0;
	for (i = 0; i < N; i++)//returns the sorted numbers from the array back into the matrix in its rightful place
	{//runs through rows
		for (j = 0; j < N; j++)//runs through columns
			if (j > i)
			{
				mat[i][j]= arr[n];
				n++;
			}
	}
	n = 0;
	for (i = 0; i < N; i++)//inserts the numbers in the lower left triangle in the matrix into the array
	{//runs through rows
		for (j = 0; j < N; j++)//runs through columns
			if (j < i)
			{
				arr[n] = mat[i][j];
				n++;
			}
	}
	sort(arr);//invites the function sort
	n = 0;
	for (i = 0; i < N; i++)//returns the sorted numbers from the array back into the matrix in its rightful place
	{//runs through rows
		for (j = 0; j < N; j++)//runs through columns
			if (j < i)
			{
				mat[i][j] = arr[n];
				n++;
			}
	}
	cout << endl << "sorted matrix:" << endl;
	for (i = 0; i < N; i++)//prints out the final sorted matrix
	{//runs through rows
		for (j = 0; j < N; j++)//runs through columns
			cout << mat[i][j] << " ";
		cout << endl;
	}
	num.close();
	system("pause");
	return 0;
}

void sort(int arr[])//this function receives an array and does an insertion sort 
{
	int n,temp;//an integer to help us with the sort
	//and an integer to help us with the swap
	for (int i = 0; i < 45; i++)//runs through the array
	{
		if (i < 44)//checks if i is not placed on the last element in the array
		{
			if (arr[i] > arr[i + 1])//checks if the number in the next element is smaller then the element in the placement i
			{
				n = i + 1;
				while (n >= 0)//runs to the beginniing of the array
				{
					if (arr[n] < arr[n - 1])//checks if the number in the element before is bigger then the element in the placement i
					{
						//does a swap
						temp = arr[n];
						arr[n] = arr[n - 1];
						arr[n - 1] = temp;
					}
					else
						break;
					n--;
				}
			}
		}
	}
}