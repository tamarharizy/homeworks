//tamar harizy 
//209927128
//This program declares an array of ten whole numbers and then gets an input of a list of 10 ascending integers.
//If the input is not correct,then the program prints ERROR and inputs again all ten numbers of the list.
//After successfully inputting the list of ten numbers, the program inputs an additional integer.
//and checks if the last number inputted appears in the list of ten numbers,by doing a binary search.
#include <iostream>
using namespace std;
//functions
int binarysearch(int arr[], int size, int num);
//const integers
const int N = 10;
//main function
int main()
{
	int arr[N];//array of the program
	int num,place;//an integer for the users input and the input that saves the place in array
	//the equals to the users input
	bool ascending = true;//boolean that checks if the users input is valid
	cout << "enter 10 numbers:" << endl;
	while (ascending==true)//checks if the user input is valid
	{
		for (int i = 0; i < N; i++)//user inputs numbers into the array
			cin >> arr[i];
		for (int j = 0; j < N; j++)//checks if the numbers are in ascending order
		{
			if (j != (N - 1))
				if (arr[j] >= arr[j + 1])
					ascending = false;
		}
		if (ascending == true)//if the input is valid
			break;//leave the loop
		else//if input isn't valid
		{
			cout << "ERROR" << endl;
			ascending = true;
		}
	}
	cout << "enter 1 number:" << endl;
	cin >> num;//user inserts the number that they want to find in the array
	place = binarysearch(arr, N, num);//invites the function binarysearch
	if (place == -1)//checks if the number was found in the array
		cout << "not found" << endl;
	else
		cout << "the number " << num << " was found at index " << place << endl;

	
	return 0;

}


int binarysearch(int arr[], int size, int num)//this function creates a binary search
//on the array to find the number the user inserted
{
	int middle = size / 2;//integer that will placed in the middle of the array
	if (arr[middle] == num)//checks if in the placement in the arrays equals
		//to the users input
		return middle;//return the placement
	else if (arr[middle] > num)//checks if the number in the placement is bigger then the users input
	{
		while (middle >= 0)
		{
			if (arr[middle] == num)//checks if in the placement in the arrays equals
		//to the users input
				return middle;//return the placement
			middle--;
		}
	}
	else//if the number in the placement is smaller then the users input
	{
		while (middle < N)
		{
			if (arr[middle] == num)//checks if in the placement in the arrays equals
		//to the users input
				return middle;//return the placement
			middle++;
		}
	}
	return -1;
}

/*output:
enter 10 numbers:
1 3 5 7 9 11 13 15 17 19
enter 1 number:
12
not found
*/