//tamar harizy 
//209927128
//this program asks the user to input two numbers, reads them into variables x and y, and prints them 
//Then swaps the data, and then prints the same message again
#include <iostream>
using namespace std;
int main()
{
	int x, y, temp;//3 integers for 2 number and a temporary integer
	cout << "enter two numbers:" << endl;
	cin >> x >> y;
	cout << "x=" << x << ",y=" << y << endl;
	temp = x;
	x = y;
	y = temp;
	cout << "x=" << x << ",y=" << y << endl;
	return 0;
}
/*output:
enter two numbers:
3
5
x=3,y=5
x=5,y=3
*/