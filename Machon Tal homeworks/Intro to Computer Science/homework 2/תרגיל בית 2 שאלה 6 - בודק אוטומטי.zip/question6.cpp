//tamar harizy 
//209927128
//this program tells the user to insert two whole numbers
//and prints their sum, difference between the first and second, their product, and the division of the first with the second. 
#include <iostream>
using namespace std;
int main()
{
	int num1, num2;//2 integer numbers
	float result;
	cout << "enter two numbers:" << endl;
	cin >> num1 >> num2;
	result = num1 + num2;
	cout << num1 << '+' << num2 << '=' << result << endl;
	result = num1 - num2;
	cout << num1 << '-' << num2 << '=' << result << endl;
	result = num1 * num2;
	cout << num1 << '*' << num2 << '=' << result << endl;
	result = (float)num1 / num2;
	cout << num1 << '/' << num2 << '=' << result << endl;
	return 0;
}
/*output:
enter two numbers:
8
4
8+4=12
8-4=4
8*4=32
8/4=2
*/