//tamar harizy 
//209927128
//this program will take two integers, a and b, and print the result of the formula: (5*a+3)/(6*b+2)
#include <iostream>
using namespace std;
int main()
{
	int a, b;//2 integer number
	double c;//double number
	cout << "enter two numbers:" << endl;
	cin >> a >> b;
	c = (float)(5*a + 3) / (6*b + 2);
	cout << "c=" << c << endl;
	return 0;
}
/*output:
enter two numbers:
2
0
c=6.5
*/