//tamar harizy 
//209927128
//this program reads the take-off time of a plane in the format: hours, minutes, seconds, and the flight time in the same format, and prints landing time.
#include <iostream>
using namespace std;
int main()
{
	int takeoffhour, takeoffmins, takeoffsecs;//three integers for hours,minutes,and seconds
	int durhours, durmins, dursecs;//three integers for duration of hours,minutes and seconds
	int temp;//temporary integer
	cout << "enter flight takeoff:" << endl;
	cin >> takeoffhour >> takeoffmins >> takeoffsecs;
	cout << "enter flight duration:" << endl;
	cin >> durhours >> durmins >> dursecs;
	takeoffhour += durhours;
	takeoffmins += durmins;
	takeoffsecs += dursecs;
	if (takeoffsecs >= 60)//checks if the seconds are more than 60
	{
		temp = takeoffsecs / 60;
		takeoffmins += temp;
		takeoffsecs = takeoffsecs - temp * 60;
		temp = 0;
	}
	if (takeoffmins >= 60)//checks if the minutes are more than 60
	{
		temp = takeoffmins / 60;
		takeoffhour += temp;
		takeoffmins = takeoffmins - temp * 60;
		temp = 0;
	}
	if (takeoffhour >= 24)//checks if the hours are more than 24
		takeoffhour = takeoffhour % 24;
	cout << "flight arrival is:" << endl;
	cout << takeoffhour << ":" << takeoffmins << ":" << takeoffsecs << endl;

	return 0;
}
/*output:
enter flight takeoff:
15
20
25
enter flight duration:
10
40
40
flight arrival is:
2:1:5*/