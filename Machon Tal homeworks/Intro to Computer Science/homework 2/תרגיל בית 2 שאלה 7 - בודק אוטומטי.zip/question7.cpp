//tamar harizy 
//209927128
//this program receives a three-digit positive number, and prints the sum of its digits.
#include <iostream>
using namespace std;
int main()
{
	int num, singulars, tens, hundreds, sum;//4 integers for 4 numbers
	cout << "enter a three digit number:" << endl;
	cin >> num;
	singulars = num % 10;
	num = num / 10;
	tens = num % 10;
	num = num / 10;
	hundreds = num % 10;
	sum = singulars + tens + hundreds;
	cout << "the sum is:" << sum << endl;
	return 0;
}
/*output:
enter a three digit number:
715
the sum is:13
*/