//tamar harizy
//209927128
//this program uses the class that i created by the user 
//inputting 2 rational numbers in the format numerator/denominator and prints if they the two numbers are equal or different
#include "Rational.h"
#include <iostream>
using namespace std;

int main()
{
	char line;//a character for when the user inputs the rational numnber
	bool prime;//a boolean that helps find out of the 2 rational numbers are equal or not
	float den, num, num1,num2;//integers for the users input
	cout << "enter two rational numbers" << endl;
	cin >> num >> line >> den;
	Rational rat1(num,den);//invites the function rational
	cin >> num >> line >> den;
	Rational rat2(num,den);//invites the function rational
	num1=rat1.GetNumer();//gets the numerator from the class in rat1
	num1 /= rat1.GetDenum();//gets the denuminator from the class in rat1
	num2 = rat2.GetNumer();//gets the numerator from the class in rat2
	num2 /= rat2.GetDenum();//gets the denuminator from the class in rat2
	prime=rat1.equal(num1, num2);//invites the function equal
	if (prime == true)//checks if both numbers are equal
		cout << "equal" << endl;
	else
	{
		cout << "different ";
		rat1.print();//prints number in class rat1
		cout << " ";
		rat2.print();//prints number in class rat2
		cout << endl;
	}

	return 0;
}
/*output:
enter two rational numbers
1/2 3/6
equal
*/
