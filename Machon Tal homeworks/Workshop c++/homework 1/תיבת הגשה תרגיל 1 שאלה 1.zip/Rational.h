#pragma once
using namespace std;
#include <iostream>
class Rational 
{
private:
	//variables of the class
	int numer;
	int denum;
public:
	Rational(int n, int d) //constructor for the class
	{
		numer = n;
		if (d == 0)
			d = 1;
		denum = d;
	};
	//methods of the class
	int GetNumer();
	void SetNumer(int num);
	void SetDenum(int den);
	int GetDenum();
	void Reduce();
	bool equal(float num1, float num2);
	void print();
};