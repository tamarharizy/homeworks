#include "Rational.h"
#include <iostream>
using namespace std;

int Rational::GetNumer()//get function for the numerator
{
	return numer;
}

void Rational::SetNumer(int num)//set function for the numerator
{
	numer = num;
}

void Rational::SetDenum(int den)//set function for the denuminator
{
	if (den != 0)//checked if the users input isnt valid
		denum = den;
	else
		denum = 1;
}

int Rational::GetDenum()//get function for the denuminator
{
	return denum;
}

void Rational::print()//this function prints the rational number
{
	cout << numer << "/" << denum ;
}

bool Rational::equal(float num1, float num2)//this function checks if the 2 rational numbers
//that it received are equal
{
	if ((num1/num2== 1) || (num2/num1 == 1))//if there equal
		return true;
	else
		return false;
}

void Rational::Reduce()//this function helps reduce our rational number
{
	for (int i = 2; i < denum; i++)
	{
		if(denum%i==0)
			if (numer%i == 0)
			{
				numer = numer / i;
				denum = denum / i;
				break;
			}
	}
}