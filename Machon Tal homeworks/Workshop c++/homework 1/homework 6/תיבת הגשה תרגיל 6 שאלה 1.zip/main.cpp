
#include "CircularList.h"
#include <iostream>
using namespace std;

int main() {

	CircularList l;
	int choice;
	do {
		try {
			cout << "Enter your choice: ";
			cin >> choice;
			int num;
			if (choice == 1) {  // Prepend
				cout << "Enter 5 numbers: ";
				for (int i = 0; i < 5; i++) {
					cin >> num;
					l.prepend(num);
				}
			}
			else if (choice == 2) {  // Append
				cout << "Enter 5 numbers: ";
				for (int i = 0; i < 5; i++) {
					cin >> num;
					l.append(num);
				}
			}
			else if (choice == 3) {  // Delete first element
				l.removeFirst();
			}
			else if (choice == 4) {  // Search for value at a position
				cout << "Enter a number: ";
				cin >> num;
				cout << l.search(num) << endl;
			}
			else if (choice == 5) {  // Clear list
				l.clear();
			}
			else if (choice == 6) {  // Check if empty
				cout << (l.isEmpty() ? "E" : "Not e") << "mpty" << endl;
			}
			else if (choice == 7) {  // Print
				cout << l << endl;
			}
			else if (choice != 0) {  // If the user entered an invalid option
				throw "Error: Must enter a choice between 0 and 7.";
			}
		}
		catch (char const* e) {
			cout << e << endl;
		}
	} while (choice != 0);
	return 0;
}

