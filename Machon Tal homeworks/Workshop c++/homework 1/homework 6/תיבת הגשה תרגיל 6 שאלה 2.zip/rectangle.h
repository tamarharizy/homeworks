#pragma once
#ifndef rectangle_h
#define rectangle_h

#include "polygon.h"
// using namespace std;

class rectangle : public polygon {
public:
	// Constructors
	rectangle();
	rectangle(int a, int b);

	// Methods
	int getAC() const;
	int getBD() const;
	int getSide(int side) const;
	void setAC(int val);
	void setBD(int val);
	void setSide(int side, int val);
};

#endif