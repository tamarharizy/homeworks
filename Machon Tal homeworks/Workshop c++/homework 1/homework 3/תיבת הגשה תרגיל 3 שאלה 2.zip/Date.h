//tamar harizy
//209927128
//this program prints Enter a date and initializes an object of type Date with the values entered.
//according to the users input,the program pre increments,post increments,adddays,inputs and compares the users information.
#pragma once
using namespace std;
#include <iostream>

class Date
{
private:
	//fields of the class
	int day;
	int month;
	int year;
public:
	//ctors
	Date() {};
	Date(int d, int m, int y);
	Date(const Date &d);
	//methods
	void setDate(int d, int m, int y);
	void print()const;
	//operators
	Date operator++();
	Date operator++(int);
	Date operator+=(int d);
	// (deep) relational operators
	bool operator>(const Date &d)const;
	bool operator<(const Date &d)const;
	bool operator==(const Date &d)const;
};
