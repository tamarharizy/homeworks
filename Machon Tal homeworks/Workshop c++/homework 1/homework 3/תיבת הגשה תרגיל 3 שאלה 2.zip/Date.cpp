using namespace std;
#include <iostream>
#include "Date.h"

Date ::Date(int d = 1, int m = 1, int y = 1970)//constructor
{
	if ((d < 1) || (d > 30))//checks if the input is valid
		d = 1;
	day = d;
	if ((m > 12) || (m < 1))//checks if the input is valid
		m = 1;
	month = m;
	if ((y < 1970) || (y > 2099))//checks if the input is valid
		y = 1970;
	year = y;
}

Date::Date(const Date &d)//copy constructor
{
	day = d.day;
	month = d.month;
	year = d.year;
}

void Date::setDate(int d, int m, int y)//this method sets the new date the user inputted
{
	if ((d >= 1) && (d <= 30))//checks if the input is valid
		day = d;
	if ((m <= 12) && (m >=1))//checks if the input is valid
		month = m;
	if ((y >= 1970) && (y <= 2099))//checks if the input is valid
		year = y;
}

void Date::print()const//this method prints out the date
{
	cout << day << "/" << month << "/" << year << endl;
}

Date Date::operator++()//pre increment operator
{
	int temp = day+1;
	if (temp > 30)//checks if the amount of days is still valid
	{
		day = 1;
		if (month == 12)//checks if the amount of months needs to change
		{
			month = 1;
			return Date(day, month, ++year);
		}
		else
		return Date(day, ++month, year);
	}
	return Date(++day, month, year);
}

Date Date::operator++(int)//post increment operator
{
	return Date(day++, month, year);
}

Date Date::operator+=(int d)//operator that adds days to the date
{
	int temp=day+ d;
	if (temp > 30)//checks if the amount of days is still valid
	{
		day = day + d - 30;;
		if (month == 12)//checks if the amount of months needs to change
		{
			month = 1;
			return Date(day, month, year++);
		}
		else
			return Date(day, month++, year);
	}
	day += d;
	return Date(day, month, year);
}

bool Date::operator>(const Date &d)const//> operator
{
	bool prime = false;
	if (d.year >= year)//checks year
		if (d.month >= month)//checks month
			if (day > day)//checks days
				prime = true;
	return prime;
}

bool Date::operator<(const Date &d)const//< operator
{
	bool prime = false;
	if (d.year <= year)//checks year
		if (d.month <= month)//checks month
			if (day < day)//checks days
				prime = true;
	return prime;
}

bool Date::operator==(const Date &d)const//== equal operator
{
	return((day == d.day) && (month == d.month) && (year == d.year));
}