#include "Date.h"
#include <iostream>
using namespace std;
//enum
enum CHOICE{NEWDATE=1,PREINCRE,POSTINCRE,ADDDAYS,BIGGER,SMALLER,EQUAL};

int main()
{
	int choose=0;
	char line1, line2;//charcters for the users input
	int d, m, y;//integers for the users input
	cout << "Enter a date" << endl;
	cin >> d >> line1 >> m >> line2 >> y;
	if ((d < 1) || (d > 30))//checks if the users input was valid
		cout << "Error day" << endl;
	if ((m > 12) || (m < 1))//checks if the users input was valid
		cout << "Error month" << endl;
	if ((y < 1970) || (y > 2099))//checks if the users input was valid
		cout << "Error year" << endl;
	Date D(d, m, y);// initializes an object of type Date with the values entered.
	D.print();//invites the method print
	while (choose != -1)//continues as long as the users inputs isnt -1
	{
		cout << "What do you want to do" << endl;
		cin >> choose;
		switch (choose)//checks what to do by what the user inputted
		{
		case NEWDATE:
		{
			cout << "Enter a date" << endl;
			cin >> d >> line1 >> m >> line2 >> y;//user inputs a new date
			D.setDate(d, m, y);//invites the method setDate
			D.print();//invites the method print
			break;
		}
		case PREINCRE:
		{
			(++D).print();// calls ++ operator and invites the method print
			break;
		}
		case POSTINCRE:
		{
			(D++).print();// calls ++ operator and invites the method print
			break;
		}
		case ADDDAYS:
		{
			cout << "Enter #days" << endl;
			cin >> d;//user inputs the amount of days he wants to add
			D.operator+=(d);// calls += operator 
			D.print();//invites the method print
			break;
		}
		case BIGGER:
		{
			cout << "Enter a date" << endl;
			cin >> d >> line1 >> m >> line2 >> y;//user inputs a date
			Date temp1(d, m, y);// initializes an object of type Date with the values entered.
			cout << ">: ";
			if (D > temp1)//> operator- checks if what the user inputted was smaller
				cout << "true";
			else
				cout << "false";
			cout << endl;
			break;
		}
		case SMALLER:
		{
			cout << "Enter a date" << endl;
			cin >> d >> line1 >> m >> line2 >> y;//user inputs a date
			Date temp2(d, m, y);// initializes an object of type Date with the values entered.
			cout << "<: ";
			if (D < temp2)//< operator- checks if what the user inputted was bigger
				cout << "true";
			else
				cout << "false";
			cout << endl;
			break;
		}
		case EQUAL: 
		{
			cout << "Enter a date" << endl;
			cin >> d >> line1 >> m >> line2 >> y;//user inputs a date
			Date temp3(d, m, y);// initializes an object of type Date with the values entered.
			cout << "==: ";
			if (D == temp3)//== operator- checks if both dates are equal
				cout << "true";
			else
				cout << "false";
			cout << endl;
			break;
		}
		}
	}

	return 0;
}

/*output:
Enter a date
-5/1/2012
ERROR day
1/1/2012
What do you want to do
1
Enter a date
5/7/2010
5/7/2010
What do you want to do
2
6/7/2010
What do you want to do
3
6/7/2010
What do you want to do
4
Enter #days
7
14/7/2010
What do you want to do
5
Enter a date
14/7/2010
>: false
What do you want to do
7
Enter a date
14/7/2010
==: true
What do you want to do
-1*/