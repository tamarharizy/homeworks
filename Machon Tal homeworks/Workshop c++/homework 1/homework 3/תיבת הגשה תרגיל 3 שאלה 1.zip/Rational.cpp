#include "Rational.h"
#include <iostream>
#include <cmath>
using namespace std;


void Rational::print()//this function prints the rational number
{
	if ((denum == 1 )|| (numer == 0)||(numer==denum))
		cout << numer<<endl;
	else
		cout << numer << "/" << denum<<endl;
}

void Rational::SetDenum(int den)//set function for the denuminator
{
	if (den != 0)//checked if the users input isnt valid
		denum = den;
	else
		denum = 1;
}

void Rational::Reduce() //this function reduces the rational number to its simplified form
{
	int mmm = findGCF();//invites the method findGCF
	numer /= mmm;//divides the rational number by the GCF
	denum /= mmm;
}

int Rational::findGCF()//this function finds the greatest common factor for the rational number
{
	int xx = abs(numer);
	int yy = abs(denum);
	int temp;
	while (xx % yy != 0) 
	{
		xx %= yy;
		if (xx < yy) 
		{
			temp = yy;
			yy = xx;
			xx = temp;
		}
	}
	return yy;
}


bool Rational::operator!=(const Rational &r)const//operator!=
{
	return ((numer != r.numer) && (denum != r.denum));
}

bool Rational::operator<(const Rational &r)const//operator<
{
	float num1 = (float)numer / denum, num2= (float)r.numer/r.denum;
	return (num1<num2);
}

bool Rational::operator>(const Rational &r)const//operator>
{
	float num1 = (float)numer / denum, num2 = (float)r.numer / r.denum;
	return (num1 > num2);
}

bool Rational::operator>=(const Rational &r)const//operator>=
{
	float num1 = (float)numer / denum, num2 = (float)r.numer / r.denum;
	return (num1 >= num2);
}

bool Rational::operator<=(const Rational &r)const//operator<=
{
	float num1 = (float)numer / denum, num2 = (float)r.numer / r.denum;
	return (num1 <= num2);
}

Rational Rational::operator-(const Rational &r)const//operator-
{
	return Rational((numer*r.denum) - (r.numer*denum), denum*r.denum);
}

Rational Rational::operator++()//operator++
{ 
	numer += denum; 
	return *this; 
}

Rational Rational::operator++(int)//operator++
{
	Rational temp = *this; 
	numer+= denum; 
	return temp;
}

Rational Rational::operator--()//operator--
{
	numer -= denum;
	return *this;
}

Rational Rational::operator--(int)//operator--
{
	Rational temp = *this;
	numer -= denum;
	return temp;
}

Rational Rational::operator/(const Rational& r) const//operator/
{
	return Rational(numer*r.denum, r.numer*denum);
}