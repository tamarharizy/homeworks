//tamar harizy
//209927128
//this program inputs 2 rational numbers from the user and prints the results of all the operations
//after finding the result of the operations it assigns one rational number to the other and runs more operations
#pragma once
using namespace std;
#include <iostream>

class Rational
{
private:
	//fields of the class
	int numer;
	int denum;
	void Reduce();
	int findGCF();
public:
	//constructors for the class
	Rational() { numer = 0; denum = 1; }
	Rational(int n, int d) : denum(d), numer(n)
	{
		if (denum == 0)
		{
			cout << "ERROR" << endl; // throw exception 
			denum = 1;
		}
		Reduce();
	} 
	//methods of the class
	int GetNumer() {return numer;}
	int GetDenum() { return denum; }
	void SetNumer(int num) {numer = num;}	
	void SetDenum(int den);
	void print();

	//relational operators
	bool operator!=(const Rational &r)const;
	bool operator<(const Rational &r)const;
	bool operator>(const Rational &r)const;
    bool operator>=(const Rational &r)const;
	bool operator<=(const Rational &r)const;
	// arithmetic operator
	Rational operator-(const Rational &r)const;
	Rational operator/(const Rational &r) const;
	// auto-increment/decrement operators
	Rational operator++();
	Rational operator++(int); 
	Rational operator--();
	Rational operator--(int);
};