#include "Rational.h"
#include <iostream>
using namespace std;

int main()
{
	char line;//a character for when the user inputs the rational numnber
	float den, num;// integers for the users input
	cout << "Enter two rational numbers" << endl;
	cout << "a: "<<endl;
	cin >> num >> line >> den;//users input
	Rational a(num, den);//creates a new class type rational 
	cout << "b: "<<endl;
	cin >> num >> line >> den;//users input
	Rational b(num, den);//creates a new class type rational 
	cout << "b-a: ";
	(b - a).print();//call the print method and the operator-
	cout << "a!=b: ";
	if (a != b)//checks if a and b are not equal
		cout << "true";
	else
		cout << "false";
	cout << endl;
	cout << "a<b: ";
	if (a < b)//checks if the rational number a is smaller then b
		cout << "true";
	else
		cout << "false";
	cout << endl;
	cout << "a>b: ";
	if (a > b)//checks if the rational number a is bigger then b
		cout << "true";
	else
		cout << "false";
	cout << endl;
	cout << "a>=b: ";
	if (a >= b)//checks if the rational number a is bigger or equal then b
		cout << "true";
	else
		cout << "false";
	cout << endl;
	cout << "a++: ";
	(a++).print();//call the print method and the operator++
	cout << "--a: ";
	(--a).print();//call the print method and the operator--
	cout << "a--: ";
	(a--).print();//call the print method and the operator--
	b = a;//rational number b is now equal to rational number a
	cout << "b-a: ";
	(b - a).print();//call the print method and the operator-
	cout << "b/a: ";
	(b / a).print();//call the print method and the operator/
	cout << "a!=b: ";
	if (a != b)//checks if a and b are not equal
		cout << "true";
	else
		cout << "false";
	cout << endl;
	cout << "a<b: ";
	if (a < b)//checks if the rational number a is smaller then b
		cout << "true";
	else
		cout << "false";
	cout << endl;
	cout << "a>=b: ";
	if (a >= b)//checks if the rational number a is bigger or equal then b
		cout << "true";
	else
		cout << "false";
	cout << endl;

	return 0;
}
/*output:
Enter two rational numbers
a:
2/3
b:
3/4
b-a: 1/12
a!=b: true
a<b: true
a>b: false
a>=b: false
a++: 2/3
--a: 2/3
a--: 2/3
b-a: 0
b/a: -1
a!=b: false
a<b: false
a>=b: true
*/