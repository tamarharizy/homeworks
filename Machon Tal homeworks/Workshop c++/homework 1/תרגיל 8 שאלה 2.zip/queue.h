//tamar harizy
//209927128
#ifndef queue_h
#define queue_h

template <class T>
class queue {
public:
	virtual void clear() = 0;
	virtual void enqueue(const T& value) = 0;
	virtual T dequeue() = 0;
	virtual T front() const = 0;
	virtual bool isEmpty() const = 0;
};

#endif