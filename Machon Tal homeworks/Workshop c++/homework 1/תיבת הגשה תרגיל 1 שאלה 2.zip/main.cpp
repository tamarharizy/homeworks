//tamar harizy
//209927128
//this program inputs data for a companys employees. 
//For each employee, it inputs the following data: id, name, hourly wage, number of hours worked, number of overtime hours worked
//once all the info of all the employees are inserted the program output the employee with the highest salary 
//and the employee with the most amount of hours worked
#include "Employee.h"
#include <iostream>
#include<cstring>
using namespace std;

int main()
{
	int id, hworked, hovertime;//integers for the users input
	float wage;//float for the users input
	char name[20];//string for the users input
	cout << "enter details, to end enter 0" << endl;
	cin >> id;
	int index = 1;
	Employee *arr = new Employee[index];//creates an array classes
	//in order to store the information of the employees
	int count = 0;
	while (id != 0)//continues as long the user doesnt input 0 as an id
	{
		cin>> name >> wage >> hworked >> hovertime;
		while ((wage<0)||(hworked<0)||(hovertime<0))//checks if the users input is valid
		{
			cout << "ERROR" << endl;
			cin >> id;
			if (id == 0)//checks if the user inputted 0 as the id
				break;
			cin>> name >> wage >> hworked >> hovertime;
		}
		if (id != 0)//checks if the user inputted 0 as the id
		{
			if (count == index)//checks if there is no more room in the array to insert more information
			{
				index *= 2;//doubling the size of the array
				Employee *temp = new Employee[index];//creates a temporary array double the size of the previous array
				for (int j = 0; j < index / 2; j++)//copy all the info from the previous array to the new array
					temp[j] = arr[j];
				delete arr;//deletes the previous array
				arr = temp;//previous array equals to the new array
			}
			Employee emp(id, name, wage, hworked, hovertime);//invites the function Employee-constructor
			arr[count] = emp;//inserts the employee into the array
			cin >> id;
			count++;//increments the placement in the array
		}
	}
	float maxhours,maxsalary;//floats to help us compare and find the highest salary and the highest amount of hours worked
	int place_maxhours, place_maxsalary;//integers to help us save the placement inside the array of employees
	//to which have the highest salary and the highest amount of hours
	for (int i = 0; i < count; i++)//runs through the array of employees
	{
		if (i == 0)//checks if the i is placed in the beginning of the array
		{
			place_maxhours = i;
			place_maxsalary = i;
			maxhours = arr[i].GetWorked()+arr[i].GetOvertime();
			maxsalary = arr[i].Salary();
		}
		else
		{
			if ((arr[i].GetWorked() + arr[i].GetOvertime()) > maxhours)//checks if the hours in place i are bigger than the max hours
			{
				place_maxhours = i;
				maxhours = arr[i].GetWorked();
				maxhours+=arr[i].GetOvertime();
			}
			if (arr[i].Salary() >= maxsalary)//checks if the salary in place i is bigger than the max salary
			{
				place_maxsalary = i;
				maxsalary = arr[i].Salary();
			}
		}
	}
	//prints final result
	cout << "highest salary: " << arr[place_maxsalary].GetId() << " " << arr[place_maxsalary].GetName() << endl;
	cout << "hardest worker: " << arr[place_maxhours].GetId() << " " << arr[place_maxhours].GetName() << endl;
	return 0;
}
/*output:
enter details, to end enter 0
86896808 avraham 50 40 2
97708999 yaakov 100 30 0
49570379 sara 30 45 100
0
highest salary: 49570379 sara
hardest worker: 49570379 sara
*/