//tamar harizy
//209927128
#pragma once
using namespace std;
#include <iostream>
#include<cstring>

class Employee
{
private:
	//parameters of the class
	int ID;
	char name[20];
	float hwage;
	int hworked;
	int hovertime;
public:
	Employee() //default constructor for the class
	{
		ID = hworked = hovertime = 0;
		hwage = 0;
	};
	Employee(int idnum, char pname[], float wage, int worked, int overtime)//constructor for the class
	{
		ID = idnum;
		strcpy(name, pname);
		hwage = wage;
		hworked = worked;
		hovertime = overtime;
	}
	//methods for the class
	int GetId();
	char* GetName();
	float GetWage();
	int GetWorked();
	int GetOvertime();
	void SetId(int id);
	void SetName(char pname[]);
	void SetWage(float wage);
	void SethWorked(int worked);
	void SethOvertime(int overtime);
	float Salary();
};