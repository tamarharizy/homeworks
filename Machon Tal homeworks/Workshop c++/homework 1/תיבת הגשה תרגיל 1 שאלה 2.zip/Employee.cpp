//tamar harizy
//209927128
#include <iostream>
#include "Employee.h"
#include<cstring>

using namespace std;

void Employee::SetName(char pname[])//set function for the name
{
	strcpy(name, pname);
}

void Employee::SetId(int id)//set function for the ID
{
	ID = id;
}

void Employee::SetWage(float wage)//set function for the wage
{
	hwage = wage;
}

void Employee::SethWorked(int worked)//set function for the hours worked
{
	hworked = worked;
}

void Employee::SethOvertime(int overtime)//set function for the overtime hours
{
	hovertime = overtime;
}

int Employee::GetId()//get function for the ID
{
	return ID;
}

int Employee::GetWorked()//get function for the hours worked
{
	return hworked;
}

int Employee::GetOvertime()//get function for the overtime hours
{
	return hovertime;
}

float Employee::GetWage()//get function for the wage
{
	return hwage;
}

char* Employee::GetName()//get function for the name
{
	return name;
}

float Employee::Salary()//this function finds the salary for the employee
{
	float salary;
	salary=hworked * hwage + hovertime * 1.5 * hwage;
	return salary;
}