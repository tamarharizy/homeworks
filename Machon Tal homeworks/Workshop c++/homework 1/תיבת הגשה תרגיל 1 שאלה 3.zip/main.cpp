//tamar harizy
//209927128
//this program inputs data for 3 circles and for each circle, prints its area and circumference.
//The program then inputs data for points.The program outputs the number of points that lie on or inside each circle.
#include "Circle.h"
#include <iostream>
#include "Point.h"

using namespace std;

int main()
{
	int x, y, radius,num;//integers for the users input 
	//and help on finding the placement of the point thats being searched
	int countA = 0, countB = 0, countC = 0;//counters for the amount of points for circle
	//that are placed on or inside the circle
	float area,hekef;//integers to save the area and the circumference of the circle
	char circle = 'A';//a character for the names of the circles
	Circle *arr = new Circle[3];//creates array of type class circle to be able to save info on all 3 circles
	cout << "enter the center point and radius of 3 circles" << endl;
	for (int i = 0; i < 3; i++)//user inputs the information throughout the array
	{
		cin >> x >>y >> radius; 
		Circle info1(radius ,x,y);//invites the function Circle-constructor
		arr[i] = info1;//saves the class that we defined inside the array
	}
	cout << "area ";
	for (int i = 0; i < 3; i++)//runs through the array of circles and finds each of their area
	{
		cout << circle << ": ";
		area = arr[i].areaofCircle();//invites the function areaofCircle
		cout << area << " ";
		circle++;
	}
	cout << endl;
	circle = 'A';
	cout << "hekef ";
	for (int i = 0; i < 3; i++)//runs through the array of circles and finds each of their circumference
	{
		cout << circle << ": ";
		hekef = arr[i].circumofCircle();//invites the function circumofCircle
		cout << hekef << " ";
		circle++;
	}
	cout << endl;
	cin >> x >> y;
	while ((x != 0) || (y != 0))//loops as long as the user doesnt input 0 0 as a point
	{
		for (int i = 0; i < 3; i++)//runs through the circles
		{
			num = arr[i].pointPlace(x, y);//invites the function pointPlace
			if ((num == 0) || (num == -1))//checks if the point is placed inside or on the circle
			{
				//checks which circle the array is placed on
				if (i == 0)
					countA++;
				else if (i == 1)
					countB++;
				else
					countC++;
			}
		}
		cin >> x >> y;
	}
	cout << "num of points in circle A:" << countA;
	cout << " B:" << countB << " C:" << countC << endl;

	return 0;
}
/*output:
enter the center point and radius of 3 circles
0 0 3
1 1 2
5 5 2
area A: 28.26 B: 12.56 C: 12.56
hekef A: 18.84 B: 12.56 C: 12.56
1 0
0 1
0 4
0 0
num of points in circle A:2 B:2 C:0
*/