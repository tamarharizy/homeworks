//tamar harizy
//209927128
#pragma once
#include <iostream>
#include "Circle.h"
#include "Point.h"
using namespace std;

class Point
{
private:
	//parameters of the class
	int x, y;
public:
	Point() //default constructor for the class
	{
		x = 0;
		y = 0;
	};
	Point(int cx, int cy)//constructor for the class
	{
		x = cx;
		y = cy;
	}
	//methods for the class
	void SetX(int cx);
	void SetY(int cy);
	int GetX();
	int GetY();
};