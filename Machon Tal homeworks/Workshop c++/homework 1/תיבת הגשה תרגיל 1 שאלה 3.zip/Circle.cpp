//tamar harizy
//209927128
#include <iostream>
#include "Circle.h"
#include "Point.h"
using namespace std;
const float pi = 3.14;

int Circle::GetRadius()//get function for the radius
{
	return radius;
}

void Circle::SetRadius(int rad)//set function for the radius
{
	radius = rad;
}

float Circle::areaofCircle()//this function finds the area of the circle
{
	return radius * radius*pi;
}

float Circle::circumofCircle()//this function finds the circumference of the circle
{
	return 2 * pi*radius;
}

int  Circle::pointPlace(int cx, int cy)
//this function finds out if the point that it received is inside or outside or on the circle
{
	int rad = radius * radius;//integer that hold the radius squared
	int place = (p.GetX() - cx)*(p.GetX() - cx) + (p.GetY() - cy)*(p.GetY() - cy);
	if (place > rad)//checks if point is outside the circle
		return 1;
	else if (place < rad)//checks if point is inside the circle
		return -1;
	else//if point is on circle
		return 0;
}
