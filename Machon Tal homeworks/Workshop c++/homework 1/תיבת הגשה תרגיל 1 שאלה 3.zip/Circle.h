//tamar harizy
//209927128
#pragma once
#include <iostream>
#include "Circle.h"
#include "Point.h"
using namespace std;


class Circle
{
private:
	//parameters of the class
	Point p;
	int radius;
public:
	Circle() {};//default constructor for the class
	Circle(int rad,int x,int y)// constructor for the class
	{
		if (rad <= 0)
			rad = 1;
		radius = rad;
		p.SetX(x);
		p.SetY(y);
	}
	//methods for the class
	int GetRadius();
	void SetRadius(int rad);
	float areaofCircle();
	float circumofCircle();
	int pointPlace(int cx, int cy);
};