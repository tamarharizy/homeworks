//tamar harizy
//209927128
#pragma once
#include "Point.h"

class Polygon
{
private:
	//members of class
	Point *p;
	int size;
public:
	Polygon() {}//default constructor
	Polygon(int num,Point *arr);//constructor
	Polygon(const Polygon &p1);//copy constructor
	~Polygon();//destructor
	//getter and setters for my class
	void SetSize(int num);
	int GetSize();
	Point * GetP();
	//method for the class
	float PeriPolygon();
};