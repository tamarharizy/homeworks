//tamar harizy
//209927128
#pragma once

class Point
{
private:
	//parameters of the class
	int x, y;
public:
	Point();//default constructor for the class
	Point(int cx, int cy);//constructor for the class
	//methods for the class
	void SetX(int cx);
	void SetY(int cy);
	int GetX();
	int GetY();
};