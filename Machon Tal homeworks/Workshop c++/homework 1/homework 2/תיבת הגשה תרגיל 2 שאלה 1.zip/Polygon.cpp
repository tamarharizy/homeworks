//tamar harizy
//209927128
#include <iostream>
#include <cmath>
#include <math.h>
#include "Point.h"
#include "Polygon.h"
using namespace std;

Polygon::Polygon(int num,Point *arr)//constructor
{
	size = num;
	p = new Point[size];
	for (int i = 0; i < size; i++)
		p[i] = arr[i];
}

Polygon::Polygon(const Polygon &p1)//copy constructor
{
	size = p1.size;
	p = new Point[p1.size];
	for(int i=0;i<p1.size;i++)
	p[i] = p1.p[i];
}

Polygon:: ~Polygon()//deconstructor
{
	if (size)
		delete[]p;
}

Point * Polygon::GetP()//get function for the pointer to the array of points
{
	return p;
}

void Polygon::SetSize(int num)//set function for the size of the array
{
	size = num;
}

int Polygon::GetSize()//get function for the size of the array
{
	return size;
}

float Polygon::PeriPolygon()//this function finds the perimeter of the polygon
{
	int i;
	float sumPer = 0;//a float to sum up the perimeter of the polygon
	for (i = 0; i < size - 1; i++)//loops through the array of points
		sumPer += sqrt((p[i].GetX() - p[i + 1].GetX())*(p[i].GetX() - p[i + 1].GetX())+ (p[i].GetY() - p[i + 1].GetY())*(p[i].GetY() - p[i + 1].GetY()));
	sumPer += sqrt((p[i].GetX() - p[0].GetX())*(p[i].GetX() - p[0].GetX()) + (p[i].GetY() - p[0].GetY())*(p[i].GetY() - p[0].GetY()));
	return sumPer;

}


