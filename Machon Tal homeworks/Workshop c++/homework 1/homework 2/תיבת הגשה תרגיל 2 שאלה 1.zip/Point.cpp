//tamar harizy
//209927128
#include <iostream>
#include "Point.h"
using namespace std;

Point::Point() //default constructor for the class
{
	x = 0;
	y = 0;
}
Point::Point(int cx, int cy)//constructor for the class
{
	x = cx;
	y = cy;
}
void Point::SetX(int cx)//set function for the x
{
	x = cx;
}

void Point::SetY(int cy)//set function for the y
{
	y = cy;
}

int Point::GetX()//get function for the x
{
	return x;
}

int Point::GetY()//get function for the y
{
	return y;
}