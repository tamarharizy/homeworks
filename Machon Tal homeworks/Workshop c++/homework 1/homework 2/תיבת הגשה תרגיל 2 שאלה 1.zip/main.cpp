//tamar harizy
//209927128
//this program reads in the data of a polygon- the amount of sides and its points
//and prints its perimeter rounded to the nearest integer value
#include <iostream>
#include "Point.h"
#include "Polygon.h"
using namespace std;

int main()
{
	int size,x,y;//integers for the users input
	bool valid = true;//boolean to help check if the users input is valid
	cout << "enter number of sides:" << endl;
	cin >> size;
	while (size < 3)//checks if the users input is valid
	{
		cout << "ERROR" << endl;
		cin >> size;//user reinputs the size
	}
	cout << "enter points:" << endl;
	Point *arr = new Point[size];//creates an array in the size size of type class point
	for (int i = 0; i < size; i++)//loops through the array for the user to input the information of the ppoint
	{
		valid = true;
		cin >> x >> y;
		Point info(x, y);//inputs the information in type class point
		for (int j = 0; j < i; j++)//loops through the array to check if the same info was already inputted
		{
			if ((arr[j].GetX() == x) && (arr[j].GetY() == y))//checks if the info of the point is the same
			{
				valid = false;
				cout << "ERROR" << endl;
				i--;//makes sure i doesnt skip a class in the array
				break;
			}
		}
		if(valid==true)//checks if information wasnt inserted already and is valid
		arr[i] = info;
	}
	Polygon p1(size,arr);//invites the constructor and inputs the information in type class polygon
	cout << p1.PeriPolygon() << endl;//invites the method PeriPolygon and finds the perimeter and prints it out

	return 0;
}
/*output
enter number of sides:
3
enter points:
10 10 10 14 13 10
12
*/