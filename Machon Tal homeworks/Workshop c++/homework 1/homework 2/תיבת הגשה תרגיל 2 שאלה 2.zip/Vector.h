//tamar harizy
//209927128
#pragma once

class Vector
{
private:
	//members of class
	int *data;
	int capacity;
	int size;
public:
	Vector();//default constructor
	Vector(int cap);//constructor
	Vector(const Vector &p);//copy constructor
	~Vector();//deconstructor
	int getCapacity();//getter function for capacity
	int getSize();//getter function for size
	//methods of class
	void print();
	void assign(const Vector &p);
	bool isEqual(const Vector &p);
	int& at(int index);
	int strcatcat(const Vector &p);
	Vector& strnewcat(const Vector &p) const;
	void clear();
	void delLast();
	void insert(int val);
};