//tamar harizy
//209927128
#include "Vector.h"
#include <iostream>
using namespace std;

Vector::Vector()//default constructor
{
	capacity = 10;
	data = new int[capacity];
	size = 0;
}

Vector::Vector(int cap =10)//constructor
{
	capacity = cap;
	data = new int[capacity];
	size = 0;
}

Vector::Vector(const Vector &p)//copy constructor
{
	capacity = p.capacity;
	size = p.size;
	for (int i = 0; i < size; i++)//loops through the vector and copys the elements
		data[i] = p.data[i];
}

Vector::~Vector()//deconstructor
{
	delete[]data;
}

int Vector::getCapacity()//get function for the capacity
{
	return capacity;
}

int Vector::getSize()//get function for the size
{
	return size;
}

void Vector::print()//this function prints out all the info in of the vector
{
	cout << "capacity: " << capacity;
	cout << " size: " << size;
	cout << " val: ";
	for (int i = 0; i < size; i++)
		cout << data[i]<<" ";
	cout << endl;
}

void Vector::assign(const Vector &p)//this function assign one vector to another vector
//and copys the information
{
	capacity = p.capacity;
	size = p.size;
	for (int i = 0; i < size; i++)
		data[i] = p.data[i];
}

bool Vector::isEqual(const Vector &p)//this function recieves a vector
//and checks if the two vectors are the same
{
	bool equal = true;
	if (size == p.size)
	{
		for (int i = 0; i < size; i++)//loops through vectors
		{
			if (data[i] != p.data[i])//checks if the elements are the same
			{
				equal = false;
				break;
			}
		}
	}
	else
		equal = false;
	return equal;
}

int& Vector::at(int index)//this function returns the element placed in the index that it was received
{
	if (index >= size)//checks if the index is in range 
		cout << "ERROR" << endl;
	else
		return data[index];
}

int Vector::strcatcat(const Vector &p)//this function finds the product of two vectors
{
	int sum = 0;
	if (size != p.size)
		cout << "ERROR" << endl;
	else
	{
		for (int i = 0; i < size; i++)//loops through the vector
			sum += data[i] * p.data[i];
	}
	return sum;
}

Vector& Vector::strnewcat(const Vector &p) const//this function concantenates two vectors
//into one new vector
{
	int place = 0,newsize;
	newsize=size+ p.size;//finds size of new vector
	int *temp = new int[newsize];//creates a temporary vector 
	for (int i = 0; i < size; i++)//loops through first vector 
	{
		temp[place] = data[i];//insert info into temporary vector
		++place;
	}
	for (int i = 0; i < p.size; i++)//loops through second vector 
	{
		temp[place] = p.data[i];//insert info into temporary vector
		++place;
	}
	Vector *v=new Vector(capacity+p.capacity);//creates pointer to new vector
	for (int i = 0; i < place; i++)//inserts info from temporary vector into new vector
		v->insert(temp[i]);
	return *v;
}


void Vector::clear()//this function clears the content of the vector
{
		delete[]data;
		size = 0;
		data = new int[size];
}


void Vector::delLast()//this function deletes the last element of the vector. 
{
	if (size == 0)
		cout << "ERROR" << endl;
	else
		size--;
}

void Vector::insert(int val)//this function appends the given val to the next open place in the vector
{
	if (size == capacity)
		cout << "ERROR" << endl;
	else
	{
		data[size] = val;
		size++;
	}
}