//tamar harizy
//209927128
//this program recieves info of vectors-data,size and capacity.
//this program is able to check if 2 vectors are the same,find the product between 2 vectors,add elements,
//delete elements,clear info of vector,and concantenate 2 vectors
#include <iostream>
#include "Vector.h"
using namespace std;

enum options {stop, assignment, isEqual, mult, add, clear, delLast};

int main()
{
	Vector v1(10), v2(10), v3;//creates 3 vectors
	for (int i = 1; i <= 4; i++)//loops through v1 and v2 and inserts info
	{
		v1.insert(i);
		v2.insert(i + 4);
	}
	int choice;
	cout << "enter your choice 0-6\n";
	cin >> choice;
	while (choice)//as long as the input isnt 0
	{
		switch (choice)
		{
		case assignment: 
			v3.assign(v1);//calls the method assign
			break;
		case isEqual:	
			if (v1.isEqual(v2)) //calls the method isEqual and checks if the 2 vectors are equal
				cout << "v1==v2\n"; 
			else 
				cout << "v1!=v2\n";
			break;
		case mult:		
			cout << "v1*v2=" << v1.strcatcat(v2) << endl;//calls the method strcatcat
			break;
		case add:		
			v3.assign(v1.strnewcat(v2));//calls the methods assign and strnewcat
			break;
		case clear:		
			v1.clear();//calls the method clear
			break;
		case delLast:	       
			v2.delLast();//calls the method delLast
			break;
		default: cout << "ERROR";
		}
		v1.print();	//prints all the vectors
		v2.print();		
		v3.print();
		cout << "enter your choice 0-6\n";
		cin >> choice;
	}
	
	return 0;
}
/*output:
enter your choice 0-6
1
capacity: 10 size: 4 val: 1 2 3 4
capacity: 10 size: 4 val: 5 6 7 8
capacity: 10 size: 4 val: 1 2 3 4
enter your choice 0-6
2
v1!=v2
capacity: 10 size: 4 val: 1 2 3 4
capacity: 10 size: 4 val: 5 6 7 8
capacity: 10 size: 4 val: 1 2 3 4
enter your choice 0-6
3
v1*v2=70
capacity: 10 size: 4 val: 1 2 3 4
capacity: 10 size: 4 val: 5 6 7 8
capacity: 10 size: 4 val: 1 2 3 4
enter your choice 0-6
4
capacity: 10 size: 4 val: 1 2 3 4
capacity: 10 size: 4 val: 5 6 7 8
capacity: 20 size: 8 val: 1 2 3 4 5 6 7 8
enter your choice 0-6
5
capacity: 10 size: 0 val:
capacity: 10 size: 4 val: 5 6 7 8
capacity: 20 size: 8 val: 1 2 3 4 5 6 7 8
enter your choice 0-6
6
capacity: 10 size: 0 val:
capacity: 10 size: 3 val: 5 6 7
capacity: 20 size: 8 val: 1 2 3 4 5 6 7 8
enter your choice 0-6
0
*/