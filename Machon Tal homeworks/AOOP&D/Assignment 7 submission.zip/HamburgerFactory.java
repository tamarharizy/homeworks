
public class HamburgerFactory {
    public static Hamburger createHamburger(String code){
        //TODO: fix
        throw new RuntimeException("wrong Hamburger");
    }
}

