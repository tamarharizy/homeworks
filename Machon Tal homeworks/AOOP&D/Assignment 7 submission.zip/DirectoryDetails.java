// TODO: Implement Composite (change this file).
public class DirectoryDetails extends FileDetails {
    public DirectoryDetails(String path, String name){
        super(path,name);
    }
    public void addFile(FileDetails fileDetails){
        // TODO: complete
    }
}